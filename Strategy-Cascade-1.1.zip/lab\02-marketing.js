/* Strategy Cascade Lab - marketing and growth tools */
(() => {
'use strict';
const L = window.__lab; if (!L) return;
const { E, N, num, pct, rows, tbl, kpi, bar, note, svg, ax, tx, clamp } = L;
const C = 'Marketing and growth';
const erf = x => { const s = x < 0 ? -1 : 1; x = Math.abs(x); const t = 1 / (1 + 0.3275911 * x); const y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x); return s * y; };
const ncdf = z => 0.5 * (1 + erf(z / Math.SQRT2));

L.add(C, 'funnel', 'Funnel conversion model', 'Turn traffic and stage conversion rates into leads, customers, revenue, CAC and ROAS.',
  [{ k: 'vis', l: 'Visitors', d: '100000' }, { k: 'lead', l: 'Visitor to lead %', d: '4' }, { k: 'qual', l: 'Lead to qualified %', d: '35' }, { k: 'opp', l: 'Qualified to opportunity %', d: '45' }, { k: 'win', l: 'Opportunity to win %', d: '25' }, { k: 'deal', l: 'Average deal value', d: '4000' }, { k: 'spend', l: 'Marketing spend', d: '60000' }],
  v => {
    const vis = N(v.vis), lead = N(v.lead) / 100, qual = N(v.qual) / 100, opp = N(v.opp) / 100, win = N(v.win) / 100, deal = N(v.deal), spend = N(v.spend);
    const nLead = vis * lead, nQual = nLead * qual, nOpp = nQual * opp, nWin = nOpp * win, rev = nWin * deal;
    const overall = vis ? nWin / vis * 100 : 0;
    return kpi([['Leads', num(nLead)], ['Opportunities', num(nOpp)], ['Customers', num(nWin)], ['Revenue', num(rev)], ['Overall conversion', pct(overall, 2)], ['CAC', nWin ? num(spend / nWin) : 'n/a'], ['ROAS', spend ? num(rev / spend, 2) + 'x' : 'n/a']]) +
      tbl(['Stage', 'Count', 'Step conversion', 'Drop-off'], [['Visitors', num(vis), '', ''], ['Leads', num(nLead), pct(lead * 100), num(vis - nLead)], ['Qualified', num(nQual), pct(qual * 100), num(nLead - nQual)], ['Opportunities', num(nOpp), pct(opp * 100), num(nQual - nOpp)], ['Customers', num(nWin), pct(win * 100), num(nOpp - nWin)]]) +
      note('A 1 point gain at the weakest stage is worth more than a 1 point gain at a strong one. Compare the drop-off column.');
  });

L.add(C, 'mmix', 'Media mix reallocation', 'Rank channels by ROAS and see the revenue effect of moving budget from the weakest to the strongest.',
  [{ k: 'v', l: 'One line per channel: name|budget|ROAS', d: 'Search|40000|3.2\nSocial|30000|2.4\nDisplay|20000|1.1\nEmail|10000|6.5', t: 't' }, { k: 'shift', l: 'Share of the weakest budget to move %', d: '20' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Channel', b: N(x[1]), roas: N(x[2]) })).filter(x => x.b);
    if (r.length < 2) return note('Add at least two channels: name|budget|ROAS.');
    const total = r.reduce((s, x) => s + x.b, 0), rev = r.reduce((s, x) => s + x.b * x.roas, 0);
    const sorted = r.slice().sort((a, b) => a.roas - b.roas), weak = sorted[0], strong = sorted[sorted.length - 1];
    const move = weak.b * N(v.shift) / 100, gain = move * (strong.roas - weak.roas);
    return kpi([['Budget', num(total)], ['Revenue', num(rev)], ['Blended ROAS', total ? num(rev / total, 2) + 'x' : 'n/a'], ['Move', num(move)], ['Revenue gain', num(gain)]]) +
      tbl(['Channel', 'Budget', 'ROAS', 'Revenue', 'Share'], r.map(x => [E(x.n), num(x.b), num(x.roas, 2) + 'x', num(x.b * x.roas), total ? pct(x.b / total * 100) : 'n/a'])) +
      note('Move ' + num(move) + ' from ' + E(weak.n) + ' (' + num(weak.roas, 2) + 'x) to ' + E(strong.n) + ' (' + num(strong.roas, 2) + 'x) for an expected ' + num(gain) + ' more revenue. Check that the strong channel can absorb the budget before you shift it.');
  });

L.add(C, 'pacing', 'Campaign budget pacing', 'Compare spend and time elapsed, then show the daily spend needed to land on budget.',
  [{ k: 'budget', l: 'Total budget', d: '120000' }, { k: 'spent', l: 'Spent to date', d: '45000' }, { k: 'day', l: 'Days elapsed', d: '30' }, { k: 'total', l: 'Total campaign days', d: '90' }],
  v => {
    const b = N(v.budget), s = N(v.spent), d = Math.max(1, N(v.day)), t = Math.max(d, N(v.total));
    const timeP = d / t * 100, spendP = b ? s / b * 100 : 0, remaining = b - s, daysLeft = t - d;
    const need = daysLeft > 0 ? remaining / daysLeft : 0, proj = d ? s / d * t : 0;
    return kpi([['Time elapsed', pct(timeP)], ['Budget used', pct(spendP)], ['Remaining', num(remaining)], ['Needed per day', num(need)], ['Projected total', num(proj)]]) +
      tbl(['Check', 'Value'], [['Pacing gap', pct(spendP - timeP)], ['Projected over or under', num(proj - b)], ['Days left', num(daysLeft)], ['Status', spendP > timeP + 5 ? '<b style="color:#c9473d">Overspending</b>' : spendP < timeP - 5 ? '<b style="color:#d9922b">Underspending</b>' : '<b style="color:#2e9d62">On pace</b>']]) +
      note('At the current daily rate you will finish at ' + num(proj) + ' against a budget of ' + num(b) + '.');
  });

L.add(C, 'abtest', 'A/B test significance', 'Lift, z-score, p-value and the sample you need before calling a winner.',
  [{ k: 'na', l: 'Visitors in A', d: '5000' }, { k: 'ca', l: 'Conversions in A', d: '250' }, { k: 'nb', l: 'Visitors in B', d: '5000' }, { k: 'cb', l: 'Conversions in B', d: '300' }, { k: 'mde', l: 'Minimum detectable lift %', d: '10' }],
  v => {
    const na = Math.max(1, N(v.na)), ca = N(v.ca), nb = Math.max(1, N(v.nb)), cb = N(v.cb);
    const pa = ca / na, pb = cb / nb, p = (ca + cb) / (na + nb);
    const se = Math.sqrt(p * (1 - p) * (1 / na + 1 / nb)), z = se ? (pb - pa) / se : 0, pv = 2 * (1 - ncdf(Math.abs(z)));
    const lift = pa ? (pb - pa) / pa * 100 : 0;
    const mde = Math.max(0.0001, N(v.mde) / 100);
    const nNeed = p ? Math.ceil(2 * p * (1 - p) * Math.pow(1.96 + 0.84, 2) / (p * mde * p * mde) * 1) : 0;
    return kpi([['A rate', pct(pa * 100, 2)], ['B rate', pct(pb * 100, 2)], ['Relative lift', pct(lift, 2)], ['p-value', pv < 0.0001 ? '<0.0001' : num(pv, 4)], ['Significant', pv < 0.05 ? 'Yes at 95%' : 'No']]) +
      tbl(['Check', 'Value'], [['Absolute difference', pct((pb - pa) * 100, 2)], ['z-score', num(z, 2)], ['Confidence', pct((1 - pv) * 100, 1)], ['Sample per arm for ' + pct(N(v.mde)) + ' lift', num(nNeed)], ['Verdict', pv < 0.05 && Math.abs(lift) > 0 ? '<b style="color:#2e9d62">Winner supported</b>' : '<b style="color:#d9922b">Keep running</b>']]) +
      note('This is a two-sided test on independent proportions. Do not stop early when the result looks good; that inflates false positives.');
  });

L.add(C, 'tamsam', 'TAM, SAM and SOM', 'Size the total, serviceable and obtainable market from population and spend assumptions.',
  [{ k: 'pop', l: 'Target population or accounts', d: '2000000' }, { k: 'pen', l: 'Share that needs the product %', d: '30' }, { k: 'spend', l: 'Annual spend per customer', d: '120' }, { k: 'sam', l: 'Serviceable share of that %', d: '40' }, { k: 'som', l: 'Share you can win in 3 years %', d: '5' }],
  v => {
    const pop = N(v.pop), pen = N(v.pen) / 100, spend = N(v.spend), samP = N(v.sam) / 100, somP = N(v.som) / 100;
    const tam = pop * pen * spend, sam = tam * samP, som = sam * somP;
    return kpi([['TAM', num(tam)], ['SAM', num(sam)], ['SOM', num(som)], ['Customers at SOM', num(som / (spend || 1))]]) +
      tbl(['Layer', 'Value', 'Basis'], [['TAM', num(tam), num(pop * pen) + ' customers x ' + num(spend)], ['SAM', num(sam), pct(samP * 100) + ' of TAM'], ['SOM', num(som), pct(somP * 100) + ' of SAM']]) +
      note('Use SOM for planning and TAM only for the story. A plan built on TAM will not survive contact with a sales team.');
  });

L.add(C, 'seo', 'SEO opportunity score', 'Rank keywords by volume, difficulty and current position to show where to invest first.',
  [{ k: 'v', l: 'One line per keyword: keyword|monthly volume|difficulty 0-100|current position (0 if none)', d: 'strategy software|2400|55|12\nokr tool|880|35|4\ncascade planning|320|20|0', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ k: x[0] || 'Keyword', vol: N(x[1]), diff: clamp(N(x[2]), 0, 100), pos: N(x[3]) })).filter(x => x.k);
    if (!r.length) return note('Add at least one keyword: keyword|volume|difficulty|position.');
    r.forEach(x => { const posBoost = x.pos === 0 ? 1.2 : x.pos <= 3 ? 0.4 : x.pos <= 10 ? 1 : x.pos <= 20 ? 0.8 : 0.5; x.score = x.vol * (1 - x.diff / 100) * posBoost; });
    const sorted = r.slice().sort((a, b) => b.score - a.score), max = sorted[0].score || 1;
    return kpi([['Keywords', r.length], ['Total volume', num(r.reduce((s, x) => s + x.vol, 0))], ['Best opportunity', E(sorted[0].k)], ['Score', num(sorted[0].score)]]) +
      tbl(['Keyword', 'Volume', 'Difficulty', 'Position', 'Score', ''], sorted.map(x => [E(x.k), num(x.vol), num(x.diff), x.pos || '-', num(x.score), bar(x.score / max * 100, '#2e6bd9')])) +
      note('High volume, low difficulty and a position just off page one usually gives the fastest return. A position of 0 means you do not rank yet.');
  });

L.add(C, 'email', 'Email list growth forecast', 'Project list size and revenue month by month from signups, churn and revenue per subscriber.',
  [{ k: 'list', l: 'Current list size', d: '20000' }, { k: 'sign', l: 'New signups per month', d: '1200' }, { k: 'churn', l: 'Monthly churn %', d: '1.5' }, { k: 'months', l: 'Months', d: '12' }, { k: 'rps', l: 'Monthly revenue per subscriber', d: '1.2' }],
  v => {
    const n = clamp(Math.round(N(v.months)), 1, 60); let s = N(v.list), rs = [];
    for (let i = 1; i <= n; i++) { const lost = s * N(v.churn) / 100; s = s - lost + N(v.sign); rs.push([i, num(lost), num(N(v.sign)), num(s), num(s * N(v.rps))]); }
    return kpi([['Ending list', num(s)], ['Net growth', num(s - N(v.list))], ['Monthly revenue', num(s * N(v.rps))], ['Annual revenue', num(s * N(v.rps) * 12)]]) +
      tbl(['Month', 'Churned', 'New', 'List', 'Revenue'], rs);
  });

L.add(C, 'attrib', 'Attribution comparison', 'Compare first-touch, last-touch and linear attribution to see which channels each model over- or under-credits.',
  [{ k: 'v', l: 'One line per channel: name|first-touch conversions|last-touch conversions|linear conversions', d: 'Search|120|300|210\nSocial|260|150|205\nEmail|90|180|135', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Channel', f: N(x[1]), l: N(x[2]), li: N(x[3]) })).filter(x => x.n);
    if (!r.length) return note('Add at least one channel: name|first|last|linear.');
    const tf = r.reduce((s, x) => s + x.f, 0), tl = r.reduce((s, x) => s + x.l, 0), tli = r.reduce((s, x) => s + x.li, 0);
    return kpi([['First-touch total', num(tf)], ['Last-touch total', num(tl)], ['Linear total', num(tli)], ['Largest gap', E(r.slice().sort((a, b) => Math.abs(b.l - b.f) - Math.abs(a.l - a.f))[0].n)]]) +
      tbl(['Channel', 'First', 'Last', 'Linear', 'Last vs first'], r.map(x => [E(x.n), num(x.f), num(x.l), num(x.li), '<span style="color:' + (x.l > x.f ? '#2e9d62' : '#c9473d') + '">' + (x.l - x.f > 0 ? '+' : '') + num(x.l - x.f) + '</span>'])) +
      note('Last-touch flatters closing channels such as search. First-touch flatters discovery. Use linear or a data-driven model for budget decisions.');
  });
})();
