/* Strategy Cascade Lab - finance and pricing tools */
(() => {
'use strict';
const L = window.__lab; if (!L) return;
const { E, N, num, pct, rows, tbl, kpi, bar, note, svg, ax, tx, clamp } = L;
const A = 'Finance and valuation';

L.add(A, 'be', 'Break-even analysis', 'Contribution margin, break-even units and revenue, the units needed for a target profit, and margin of safety.',
  [{ k: 'price', l: 'Price per unit', d: '100' }, { k: 'vc', l: 'Variable cost per unit', d: '40' }, { k: 'fixed', l: 'Fixed costs per period', d: '50000' }, { k: 'target', l: 'Target profit per period', d: '20000' }, { k: 'actual', l: 'Actual units sold', d: '1500' }],
  v => {
    const p = N(v.price), c = N(v.vc), f = N(v.fixed), t = N(v.target), a = N(v.actual);
    const cm = p - c, cmr = p ? cm / p * 100 : 0, be = cm > 0 ? f / cm : NaN, rev = be * p;
    const tu = cm > 0 ? (f + t) / cm : NaN, mos = be && a ? (a - be) / a * 100 : NaN;
    return kpi([['Contribution per unit', num(cm, 2)], ['Contribution margin', pct(cmr)], ['Break-even units', isFinite(be) ? num(Math.ceil(be)) : 'n/a'], ['Break-even revenue', isFinite(rev) ? num(rev) : 'n/a'], ['Units for target profit', isFinite(tu) ? num(Math.ceil(tu)) : 'n/a'], ['Margin of safety', isFinite(mos) ? pct(mos) : 'n/a']]) +
      tbl(['Check', 'Value'], [['Price', num(p, 2)], ['Variable cost', num(c, 2)], ['Fixed cost', num(f)], ['Target profit', num(t)], ['Profit at actual volume', num((a * cm) - f, 2)], ['Verdict', cm <= 0 ? '<b style="color:#c9473d">Price does not cover variable cost</b>' : a >= be ? '<b style="color:#2e9d62">Above break-even</b>' : '<b style="color:#d9922b">Below break-even</b>']]) +
      note('Break-even units = fixed costs / contribution per unit. Every unit above break-even adds the full contribution to profit.');
  });

L.add(A, 'amort', 'Loan amortisation schedule', 'Monthly payment, interest and principal split, total cost of credit, and the effect of extra payments.',
  [{ k: 'p', l: 'Loan principal', d: '500000' }, { k: 'rate', l: 'Annual interest rate %', d: '6' }, { k: 'y', l: 'Term in years', d: '5' }, { k: 'n', l: 'Payments per year', d: '12' }, { k: 'x', l: 'Extra payment each period', d: '0' }],
  v => {
    const P = N(v.p), rate = N(v.rate) / 100, y = Math.max(1, N(v.y)), per = Math.max(1, N(v.n)), extra = Math.max(0, N(v.x));
    const r = rate / per, n = Math.round(y * per);
    const pmt = r ? P * r / (1 - Math.pow(1 + r, -n)) : P / n;
    let bal = P, totInt = 0, k = 0, rowsO = [], firstBal = P;
    const maxK = n * 4 + 2400;
    while (bal > 0.005 && k < maxK) {
      const int = bal * r, prin = Math.min(bal, pmt - int + extra);
      const pay = prin + int;
      bal = Math.max(0, bal - prin); totInt += int; k++;
      if (k <= 12 || bal === 0) rowsO.push([k, num(firstBal, 2), num(pay, 2), num(int, 2), num(prin, 2), num(bal, 2)]);
      firstBal = bal;
    }
    const baseInt = (pmt * n) - P;
    const saved = baseInt - totInt;
    return kpi([['Payment', num(pmt + extra, 2)], ['Payoff', k + ' periods'], ['Total interest', num(totInt, 2)], ['Interest saved', extra > 0 ? num(saved, 2) : '-'], ['Total repaid', num(P + totInt, 2)]]) +
      tbl(['#', 'Opening', 'Payment', 'Interest', 'Principal', 'Closing'], rowsO) +
      note('Standard payment is ' + num(pmt, 2) + ' per period for ' + n + ' periods.' + (extra > 0 ? ' With the extra ' + num(extra, 2) + ' the loan clears in ' + k + ' periods and saves ' + num(saved, 2) + ' in interest.' : ' Add an extra payment to see the saving.'));
  });

L.add(A, 'dcf', 'Discounted cash flow', 'Present value of explicit cash flows plus a Gordon terminal value, with a value bridge.',
  [{ k: 'rate', l: 'Discount rate %', d: '10' }, { k: 'g', l: 'Terminal growth %', d: '2' }, { k: 'cf', l: 'Cash flows by year, comma separated (year 0 first)', d: '-1000,200,300,400,500', t: 't', r: 2 }],
  v => {
    const r = N(v.rate) / 100, g = N(v.g) / 100, cf = String(v.cf || '').split(',').map(N);
    if (!cf.length) return note('Enter at least one cash flow.');
    let pv = 0; const rs = cf.map((x, i) => { const d = Math.pow(1 + r, i), p = x / d; pv += p; return [i, num(x, 2), num(p, 2)]; });
    const last = cf[cf.length - 1], tv = r > g ? last * (1 + g) / (r - g) : NaN;
    const pvtv = isFinite(tv) ? tv / Math.pow(1 + r, cf.length - 1) : NaN;
    return kpi([['PV of cash flows', num(pv, 2)], ['Terminal value', isFinite(tv) ? num(tv, 2) : 'n/a'], ['PV of terminal value', isFinite(pvtv) ? num(pvtv, 2) : 'n/a'], ['Enterprise value', isFinite(pvtv) ? num(pv + pvtv, 2) : 'n/a']]) +
      tbl(['Year', 'Cash flow', 'Present value'], rs) +
      (r <= g ? note('<b>Discount rate must exceed terminal growth</b>, otherwise the terminal value is infinite.') : note('Terminal value uses the last cash flow grown at ' + pct(N(v.g)) + ' and discounted at ' + pct(N(v.rate)) + '.'));
  });

L.add(A, 'wacc', 'Weighted average cost of capital', 'Capital structure weights, after-tax cost of debt and the blended discount rate.',
  [{ k: 'e', l: 'Market value of equity', d: '700' }, { k: 'd', l: 'Market value of debt', d: '300' }, { k: 'ke', l: 'Cost of equity %', d: '12' }, { k: 'kd', l: 'Cost of debt %', d: '6' }, { k: 'tax', l: 'Tax rate %', d: '25' }],
  v => {
    const e = Math.max(0, N(v.e)), d = Math.max(0, N(v.d)), ke = N(v.ke), kd = N(v.kd), tax = N(v.tax) / 100, V = e + d;
    if (!V) return note('Enter equity and debt values.');
    const we = e / V, wd = d / V, at = kd * (1 - tax), w = we * ke + wd * at;
    return kpi([['WACC', pct(w, 2)], ['Equity weight', pct(we * 100)], ['Debt weight', pct(wd * 100)], ['After-tax cost of debt', pct(at, 2)]]) +
      tbl(['Component', 'Weight', 'Cost', 'Contribution'], [['Equity', pct(we * 100), pct(ke, 2), pct(we * ke, 2)], ['Debt', pct(wd * 100), pct(at, 2), pct(wd * at, 2)], ['<b>Total</b>', '100%', '', '<b>' + pct(w, 2) + '</b>']]) +
      note('Use WACC as the discount rate for projects with the same risk as the business. Use a higher rate for riskier projects.');
  });

L.add(A, 'unit', 'Unit economics and CAC payback', 'Gross profit per customer, CAC payback, lifetime value and the LTV to CAC ratio.',
  [{ k: 'arpu', l: 'Monthly revenue per customer', d: '50' }, { k: 'gm', l: 'Gross margin %', d: '70' }, { k: 'cac', l: 'Customer acquisition cost', d: '300' }, { k: 'churn', l: 'Monthly churn %', d: '2' }, { k: 'exp', l: 'Monthly expansion %', d: '0.5' }],
  v => {
    const arpu = N(v.arpu), gm = N(v.gm) / 100, cac = N(v.cac), ch = N(v.churn) / 100, ex = N(v.exp) / 100;
    const gp = arpu * gm, net = ch - ex, pb = gp > 0 ? cac / gp : NaN, ltv = net > 0 ? gp / net : NaN, ratio = cac > 0 && isFinite(ltv) ? ltv / cac : NaN;
    return kpi([['Gross profit / month', num(gp, 2)], ['CAC payback', isFinite(pb) ? num(pb, 1) + ' months' : 'never'], ['Lifetime value', isFinite(ltv) ? num(ltv, 2) : 'unbounded'], ['LTV : CAC', isFinite(ratio) ? num(ratio, 2) + 'x' : 'n/a']]) +
      tbl(['Check', 'Value'], [['Net revenue churn', pct(net * 100, 2)], ['Gross margin per customer', num(gp, 2)], ['Payback in years', isFinite(pb) ? num(pb / 12, 2) : 'n/a'], ['Healthy LTV:CAC', ratio >= 3 ? '<b style="color:#2e9d62">Yes, above 3x</b>' : '<b style="color:#d9922b">Below the usual 3x benchmark</b>']]) +
      note('Net revenue churn is churn minus expansion. If expansion is higher than churn, lifetime value is unbounded and the ratio cannot be calculated.');
  });

L.add(A, 'varw', 'Budget variance waterfall', 'Compare budget with actual by line and show the bridge from budget to actual.',
  [{ k: 'v', l: 'One line per item: name|budget|actual', d: 'Marketing|120000|135000\nSales|80000|72000\nOperations|60000|66000', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Item', b: N(x[1]), a: N(x[2]) })).filter(x => x.b || x.a);
    if (!r.length) return note('Add at least one line in the form name|budget|actual.');
    const tb = r.reduce((s, x) => s + x.b, 0), ta = r.reduce((s, x) => s + x.a, 0);
    const W = 460, H = 200, pad = 34, max = Math.max(tb, ta, ...r.map(x => Math.max(x.b, x.a))) || 1;
    const n = r.length + 2, bw = (W - pad * 2) / n;
    const Y = x => H - pad - (H - pad * 1.6) * (x / max);
    const barAt = (i, from, to, fill, label) => {
      const y0 = Y(from), y1 = Y(to), yy = Math.min(y0, y1), hh = Math.max(2, Math.abs(y1 - y0));
      return '<rect x="' + (pad + bw * i + 3) + '" y="' + yy + '" width="' + (bw - 6) + '" height="' + hh + '" rx="2" fill="' + fill + '" fill-opacity=".85"/>' + tx(pad + bw * i + bw / 2, H - pad + 13, label);
    };
    let bars = barAt(0, 0, tb, '#6b7280', 'Budget'), cum = tb;
    r.forEach((x, i) => {
      const d = x.a - x.b;
      bars += barAt(i + 1, cum, cum + d, d >= 0 ? '#2e9d62' : '#c9473d', x.n);
      cum += d;
    });
    bars += barAt(n - 1, 0, ta, '#2e6bd9', 'Actual');
    return kpi([['Budget', num(tb)], ['Actual', num(ta)], ['Variance', num(ta - tb)], ['Variance %', tb ? pct((ta - tb) / tb * 100) : 'n/a']]) +
      svg(W, H, ax(pad, H - pad, W - pad, H - pad) + bars) +
      tbl(['Line', 'Budget', 'Actual', 'Variance', '%'], r.map(x => [E(x.n), num(x.b), num(x.a), '<span style="color:' + (x.a > x.b ? '#c9473d' : '#2e9d62') + '">' + num(x.a - x.b) + '</span>', x.b ? pct((x.a - x.b) / x.b * 100) : 'n/a']));
  });

L.add(A, 'cf13', '13-week cash flow forecast', 'Weekly opening and closing cash, the lowest point, and the first week below your minimum.',
  [{ k: 'open', l: 'Opening cash', d: '250000' }, { k: 'in', l: 'Weekly inflows, comma separated (13 values)', d: '90000,90000,90000,90000,90000,90000,90000,90000,90000,90000,90000,90000,90000', t: 't', r: 2 }, { k: 'out', l: 'Weekly outflows, comma separated (13 values)', d: '95000,95000,95000,95000,95000,95000,95000,95000,95000,95000,95000,95000,95000', t: 't', r: 2 }, { k: 'min', l: 'Minimum cash buffer', d: '100000' }],
  v => {
    const ins = String(v.in || '').split(',').map(N), outs = String(v.out || '').split(',').map(N);
    const weeks = Math.max(ins.length, outs.length, 1), min = N(v.min);
    let cash = N(v.open), low = cash, lowW = 0, first = null, rs = [];
    for (let i = 0; i < weeks; i++) {
      const a = ins[i] || 0, b = outs[i] || 0;
      cash += a - b;
      if (cash < low) { low = cash; lowW = i + 1; }
      if (first === null && cash < min) first = i + 1;
      rs.push([i + 1, num(a), num(b), num(a - b), num(cash), cash < min ? '<b style="color:#c9473d">Below buffer</b>' : '']);
    }
    return kpi([['Closing cash', num(cash)], ['Lowest cash', num(low)], ['Lowest week', 'Week ' + lowW], ['First breach', first ? 'Week ' + first : 'None']]) +
      tbl(['Week', 'In', 'Out', 'Net', 'Closing', ''], rs) +
      note(first ? 'Cash falls below the buffer in week ' + first + '. Raise funding, delay payments or accelerate collections before then.' : 'Cash stays above the buffer across the horizon.');
  });

L.add(A, 'mbridge', 'Margin bridge', 'Split the change in gross profit into a volume effect and a margin effect.',
  [{ k: 'r0', l: 'Prior revenue', d: '1000000' }, { k: 'm0', l: 'Prior gross margin %', d: '40' }, { k: 'r1', l: 'Current revenue', d: '1200000' }, { k: 'm1', l: 'Current gross margin %', d: '36' }],
  v => {
    const r0 = N(v.r0), m0 = N(v.m0) / 100, r1 = N(v.r1), m1 = N(v.m1) / 100;
    const g0 = r0 * m0, g1 = r1 * m1, vol = (r1 - r0) * m0, mar = r1 * (m1 - m0);
    return kpi([['Prior gross profit', num(g0)], ['Current gross profit', num(g1)], ['Change', num(g1 - g0)], ['Volume effect', num(vol)], ['Margin effect', num(mar)]]) +
      tbl(['Driver', 'Amount', 'Share of change'], [['Volume', num(vol), (g1 - g0) ? pct(vol / (g1 - g0) * 100) : 'n/a'], ['Margin', num(mar), (g1 - g0) ? pct(mar / (g1 - g0) * 100) : 'n/a'], ['<b>Total</b>', '<b>' + num(g1 - g0) + '</b>', '100%']]) +
      note('Volume effect = change in revenue at the old margin. Margin effect = current revenue at the change in margin.');
  });

L.add(A, 'lease', 'Lease or buy', 'Compare the present value of leasing against buying, including residual value and maintenance.',
  [{ k: 'cost', l: 'Purchase cost', d: '120000' }, { k: 'm', l: 'Monthly lease payment', d: '2500' }, { k: 'term', l: 'Term in months', d: '48' }, { k: 'res', l: 'Residual value % of cost', d: '20' }, { k: 'rate', l: 'Discount rate % per year', d: '8' }, { k: 'maint', l: 'Annual maintenance if owned', d: '1200' }],
  v => {
    const c = N(v.cost), m = N(v.m), t = Math.max(1, N(v.term)), res = N(v.res) / 100, r = N(v.rate) / 1200, maint = N(v.maint);
    const ann = r ? (1 - Math.pow(1 + r, -t)) / r : t;
    const pvLease = m * ann;
    const pvRes = c * res / Math.pow(1 + r, t);
    const pvMaint = maint * (ann / 12);
    const pvBuy = c - pvRes + pvMaint;
    return kpi([['PV of leasing', num(pvLease)], ['PV of buying', num(pvBuy)], ['Difference', num(pvBuy - pvLease)], ['Cheaper option', pvLease < pvBuy ? 'Lease' : 'Buy']]) +
      tbl(['Component', 'Amount'], [['Lease payments', num(pvLease)], ['Purchase', num(c)], ['PV of residual', '-' + num(pvRes)], ['PV of maintenance', num(pvMaint)], ['<b>PV of buying</b>', '<b>' + num(pvBuy) + '</b>']]) +
      note('This compares cash cost only. Consider tax treatment, balance-sheet presentation, flexibility and the risk that the residual value is wrong.');
  });

L.add(A, 'div', 'Dividend or buyback', 'Compare cash returned as a dividend against a share buyback and the effect on earnings per share.',
  [{ k: 'sh', l: 'Shares outstanding', d: '1000000' }, { k: 'price', l: 'Share price', d: '20' }, { k: 'cash', l: 'Cash available', d: '500000' }, { k: 'eps', l: 'Earnings per share', d: '2' }, { k: 'dps', l: 'Planned dividend per share', d: '0.5' }],
  v => {
    const sh = Math.max(1, N(v.sh)), p = N(v.price), cash = N(v.cash), eps = N(v.eps), dps = N(v.dps);
    const earn = sh * eps;
    const divTotal = dps * sh;
    const buyShares = p > 0 ? Math.min(sh, cash / p) : 0;
    const newSh = sh - buyShares;
    const epsBuy = newSh ? earn / newSh : NaN;
    return kpi([['Dividend cost', num(divTotal)], ['Dividend yield', p ? pct(dps / p * 100, 2) : 'n/a'], ['Shares repurchased', num(buyShares)], ['EPS after buyback', num(epsBuy, 2)]]) +
      tbl(['Route', 'Cash used', 'Shares after', 'EPS after', 'Yield'], [['Dividend', num(divTotal), num(sh), num(eps, 2), p ? pct(dps / p * 100, 2) : 'n/a'], ['Buyback', num(cash), num(newSh), num(epsBuy, 2), p ? pct(epsBuy / p * 100, 2) : 'n/a'], ['Do nothing', '0', num(sh), num(eps, 2), p ? pct(eps / p * 100, 2) : 'n/a']]) +
      note('A buyback raises EPS only if the earnings yield (EPS / price) is above the after-tax return on the cash. Otherwise it destroys value.');
  });

/* ---------------- pricing and revenue ---------------- */
const P = 'Pricing and revenue';

L.add(P, 'elast', 'Price elasticity simulator', 'Model volume, revenue and profit at a new price using an elasticity estimate.',
  [{ k: 'p', l: 'Current price', d: '100' }, { k: 'c', l: 'Variable cost per unit', d: '40' }, { k: 'q', l: 'Current units', d: '10000' }, { k: 'e', l: 'Price elasticity (negative)', d: '-1.5' }, { k: 'np', l: 'New price', d: '110' }],
  v => {
    const p = N(v.p), c = N(v.c), q = N(v.q), e = N(v.e), np = N(v.np);
    const dp = p ? (np - p) / p : 0, dq = e * dp, nq = Math.max(0, q * (1 + dq));
    const r0 = p * q, r1 = np * nq, pr0 = (p - c) * q, pr1 = (np - c) * nq;
    const beLoss = (p - c) / (np - c) - 1;
    return kpi([['Price change', pct(dp * 100)], ['Volume change', pct(dq * 100)], ['New units', num(nq)], ['Revenue change', num(r1 - r0)], ['Profit change', num(pr1 - pr0)]]) +
      tbl(['Metric', 'Now', 'At new price'], [['Price', num(p, 2), num(np, 2)], ['Units', num(q), num(nq)], ['Revenue', num(r0), num(r1)], ['Gross profit', num(pr0), num(pr1)], ['Margin', pct((p - c) / p * 100), pct((np - c) / np * 100)]]) +
      note('The volume you can lose before profit falls is ' + pct(-beLoss * 100) + '. Your assumed loss is ' + pct(-dq * 100) + '.');
  });

L.add(P, 'disc', 'Discount ladder', 'See the margin and the extra volume needed at each discount level to keep the same profit.',
  [{ k: 'list', l: 'List price', d: '100' }, { k: 'cost', l: 'Unit cost', d: '40' }, { k: 'base', l: 'Units sold at list price', d: '1000' }, { k: 'd', l: 'Discounts to test, comma separated %', d: '0,5,10,15,20,25,30' }],
  v => {
    const lp = N(v.list), c = N(v.cost), base = Math.max(1, N(v.base)), ds = String(v.d || '').split(',').map(N);
    const baseProfit = (lp - c) * base;
    const rs = ds.map(d => {
      const price = lp * (1 - d / 100), m = price - c, units = m > 0 ? baseProfit / m : Infinity;
      return [pct(d), num(price, 2), num(m, 2), price ? pct(m / price * 100) : 'n/a', isFinite(units) ? num(Math.ceil(units)) : 'never', isFinite(units) ? pct((units / base - 1) * 100) : 'n/a'];
    });
    return kpi([['List margin', pct((lp - c) / lp * 100)], ['Profit at list', num(baseProfit)], ['Break-even discount', pct((1 - c / lp) * 100)]]) +
      tbl(['Discount', 'Price', 'Margin / unit', 'Margin %', 'Units needed', 'Volume uplift needed'], rs) +
      note('A discount cuts straight into margin. At a 40% unit cost, a 20% discount needs far more than 20% extra volume to stand still.');
  });

L.add(P, 'mrr', 'MRR and ARR projection', 'Project recurring revenue month by month with new business, churn and expansion.',
  [{ k: 'mrr', l: 'Starting MRR', d: '50000' }, { k: 'new', l: 'New MRR per month', d: '8000' }, { k: 'churn', l: 'Monthly churn %', d: '2' }, { k: 'exp', l: 'Monthly expansion %', d: '1' }, { k: 'months', l: 'Months to project', d: '12' }],
  v => {
    const n = clamp(Math.round(N(v.months)), 1, 60);
    let mrr = N(v.mrr), rs = [], total = 0;
    for (let i = 1; i <= n; i++) {
      const ch = mrr * N(v.churn) / 100, ex = mrr * N(v.exp) / 100, add = N(v.new);
      mrr = mrr - ch + ex + add; total += add;
      rs.push([i, num(add), num(ch), num(ex), num(mrr), num(mrr * 12)]);
    }
    return kpi([['Ending MRR', num(mrr)], ['Ending ARR', num(mrr * 12)], ['Net new MRR', num(mrr - N(v.mrr))], ['Average monthly growth', pct((Math.pow(mrr / (N(v.mrr) || 1), 1 / n) - 1) * 100, 2)]]) +
      tbl(['Month', 'New', 'Churn', 'Expansion', 'MRR', 'ARR'], rs);
  });

L.add(P, 'vw', 'Price sensitivity range', 'Turn four price points into an acceptable price band and a recommended test price.',
  [{ k: 'tc', l: 'Too cheap at or below', d: '40' }, { k: 'ch', l: 'A bargain at', d: '60' }, { k: 'ex', l: 'Getting expensive at', d: '100' }, { k: 'te', l: 'Too expensive at or above', d: '140' }],
  v => {
    const tc = N(v.tc), ch = N(v.ch), ex = N(v.ex), te = N(v.te);
    const pmc = (tc + ch) / 2, pme = (ex + te) / 2, opp = (ch + ex) / 2;
    return kpi([['Marginal cheapness', num(pmc, 2)], ['Indifference price', num(opp, 2)], ['Marginal expensiveness', num(pme, 2)], ['Acceptable band', num(pmc, 2) + ' to ' + num(pme, 2)]]) +
      tbl(['Point', 'Price', 'Meaning'], [['Too cheap', num(tc, 2), 'Below this, quality is doubted'], ['Bargain', num(ch, 2), 'Strong value'], ['Expensive', num(ex, 2), 'Still acceptable'], ['Too expensive', num(te, 2), 'Demand falls away'], ['<b>Recommended test</b>', '<b>' + num(opp, 2) + '</b>', 'Run a price test around this point']]) +
      note('Simplified Van Westendorp reading. Test the recommended price on a real sample before you change list prices.');
  });

L.add(P, 'pricemix', 'Revenue and margin mix', 'Revenue, gross profit, mix share and weighted margin for a product or service range.',
  [{ k: 'v', l: 'One line per product: name|units|price|variable cost', d: 'Core|5000|100|40\nPlus|2000|150|60\nBasic|3000|60|25', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Item', u: N(x[1]), p: N(x[2]), c: N(x[3]) })).filter(x => x.u || x.p);
    if (!r.length) return note('Add at least one line: name|units|price|variable cost.');
    const rev = r.reduce((s, x) => s + x.u * x.p, 0), gp = r.reduce((s, x) => s + x.u * (x.p - x.c), 0);
    return kpi([['Revenue', num(rev)], ['Gross profit', num(gp)], ['Gross margin', rev ? pct(gp / rev * 100) : 'n/a'], ['Products', r.length]]) +
      tbl(['Product', 'Units', 'Price', 'Revenue', 'Mix %', 'GP / unit', 'Margin %'], r.map(x => { const rv = x.u * x.p; return [E(x.n), num(x.u), num(x.p, 2), num(rv), rev ? pct(rv / rev * 100) : 'n/a', num(x.p - x.c, 2), x.p ? pct((x.p - x.c) / x.p * 100) : 'n/a']; })) +
      note('Weighted margin is ' + (rev ? pct(gp / rev * 100) : 'n/a') + '. Shift volume towards the highest-margin lines to lift it without raising prices.');
  });

L.add(P, 'priceinc', 'Price increase impact', 'The profit effect of a price rise once you allow for lost volume, and the break-even volume loss.',
  [{ k: 'p', l: 'Current price', d: '100' }, { k: 'q', l: 'Current units', d: '10000' }, { k: 'c', l: 'Variable cost per unit', d: '40' }, { k: 'inc', l: 'Price increase %', d: '8' }, { k: 'loss', l: 'Expected volume loss %', d: '5' }],
  v => {
    const p = N(v.p), q = N(v.q), c = N(v.c), inc = N(v.inc) / 100, loss = N(v.loss) / 100;
    const np = p * (1 + inc), nq = q * (1 - loss);
    const pr0 = (p - c) * q, pr1 = (np - c) * nq;
    const beLoss = 1 - (p - c) / (np - c);
    return kpi([['New price', num(np, 2)], ['New units', num(nq)], ['Profit now', num(pr0)], ['Profit after', num(pr1)], ['Change', num(pr1 - pr0)]]) +
      tbl(['Check', 'Value'], [['Break-even volume loss', pct(beLoss * 100)], ['Assumed volume loss', pct(loss * 100)], ['Headroom', pct((beLoss - loss) * 100)], ['Verdict', loss <= beLoss ? '<b style="color:#2e9d62">Raises profit</b>' : '<b style="color:#c9473d">Lowers profit</b>']]) +
      note('You can lose up to ' + pct(beLoss * 100) + ' of volume and still keep profit flat. Anything less than that is upside.');
  });

L.add(P, 'bundle', 'Bundle profitability', 'Compare a bundle price with the sum of standalone prices and show the margin effect.',
  [{ k: 'v', l: 'One line per item: name|standalone price|cost', d: 'Software|60|10\nSupport|40|15\nTraining|50|20', t: 't' }, { k: 'bp', l: 'Bundle price', d: '120' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Item', p: N(x[1]), c: N(x[2]) })).filter(x => x.p || x.c);
    if (!r.length) return note('Add at least one line: name|standalone price|cost.');
    const sum = r.reduce((s, x) => s + x.p, 0), cost = r.reduce((s, x) => s + x.c, 0), bp = N(v.bp);
    return kpi([['Standalone total', num(sum)], ['Bundle price', num(bp)], ['Discount', sum ? pct((1 - bp / sum) * 100) : 'n/a'], ['Bundle margin', bp ? pct((bp - cost) / bp * 100) : 'n/a']]) +
      tbl(['Item', 'Standalone', 'Cost', 'Margin'], r.map(x => [E(x.n), num(x.p, 2), num(x.c, 2), x.p ? pct((x.p - x.c) / x.p * 100) : 'n/a'])) +
      note('Bundle cost is ' + num(cost, 2) + ' and contribution is ' + num(bp - cost, 2) + '. A bundle wins when it raises total contribution even at a lower price per item.');
  });

L.add(P, 'chanmargin', 'Channel margin waterfall', 'Work back from the consumer price to your net price and margin through retailer and distributor margins.',
  [{ k: 'cp', l: 'Consumer price', d: '100' }, { k: 'ret', l: 'Retailer margin %', d: '30' }, { k: 'dist', l: 'Distributor margin %', d: '15' }, { k: 'cogs', l: 'Your cost of goods', d: '25' }],
  v => {
    const cp = N(v.cp), ret = N(v.ret) / 100, dist = N(v.dist) / 100, cogs = N(v.cogs);
    const distPrice = cp * (1 - ret), yourPrice = distPrice * (1 - dist), gp = yourPrice - cogs;
    return kpi([['Your net price', num(yourPrice, 2)], ['Gross profit', num(gp, 2)], ['Gross margin', yourPrice ? pct(gp / yourPrice * 100) : 'n/a'], ['Share of consumer price', cp ? pct(yourPrice / cp * 100) : 'n/a']]) +
      tbl(['Step', 'Price', 'Margin taken'], [['Consumer price', num(cp, 2), ''], ['Retailer margin', num(cp - distPrice, 2), pct(ret * 100)], ['Distributor price', num(distPrice, 2), ''], ['Distributor margin', num(distPrice - yourPrice, 2), pct(dist * 100)], ['<b>Your net price</b>', '<b>' + num(yourPrice, 2) + '</b>', '']]) +
      note('You keep ' + (cp ? pct(yourPrice / cp * 100) : 'n/a') + ' of what the consumer pays. A 5 point retailer margin rise costs ' + num(cp * 0.05 * (1 - dist), 2) + ' per unit.');
  });
})();
