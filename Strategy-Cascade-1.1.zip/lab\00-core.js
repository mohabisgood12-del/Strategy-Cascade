/* Strategy Cascade Lab - core: registry, UI, command palette, app polish */
(() => {
'use strict';
const D = document;
const $ = (s, r) => (r || D).querySelector(s);
const $$ = (s, r) => [...(r || D).querySelectorAll(s)];
const A = () => window.__app;
const E = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const N = x => { const m = String(x == null ? '' : x).replace(/,/g, '').match(/-?\d+(?:\.\d+)?/); return m ? parseFloat(m[0]) : 0; };
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const num = (x, d) => { const n = Number(x); return isFinite(n) ? n.toLocaleString(undefined, { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 }) : 'n/a'; };
const pct = (x, d) => isFinite(Number(x)) ? num(x, d == null ? 1 : d) + '%' : 'n/a';
const rows = t => String(t || '').split('\n').map(l => l.trim()).filter(Boolean).map(l => l.split('|').map(x => x.trim()));
const today = () => { const a = A(); return a ? a.todayISO() : new Date().toISOString().slice(0, 10); };
const days = d => { const t = Date.parse(d); return isFinite(t) ? Math.ceil((t - Date.parse(today())) / 864e5) : null; };
const col = (v, good, warn) => v >= good ? '#2e9d62' : v >= warn ? '#d9922b' : '#c9473d';
const tbl = (head, rs, foot) => '<div class="labtbl"><table><thead><tr>' + head.map(h => '<th>' + h + '</th>').join('') + '</tr></thead><tbody>' + rs.map(r => '<tr>' + r.map(c => '<td>' + c + '</td>').join('') + '</tr>').join('') + '</tbody>' + (foot ? '<tfoot><tr>' + foot.map(c => '<td>' + c + '</td>').join('') + '</tr></tfoot>' : '') + '</table></div>';
const kpi = arr => '<div class="labkpi">' + arr.map(x => '<div><b>' + x[1] + '</b><span>' + E(x[0]) + '</span></div>').join('') + '</div>';
const bar = (p, c) => '<span class="labbar"><i style="width:' + clamp(Number(p) || 0, 0, 100) + '%' + (c ? ';background:' + c : '') + '"></i></span>';
const note = t => '<p class="labnote">' + t + '</p>';
const svg = (w, h, inner) => '<svg viewBox="0 0 ' + w + ' ' + h + '" class="labsvg" role="img">' + inner + '</svg>';
const ax = (x1, y1, x2, y2) => '<line x1="' + x1 + '" y1="' + y1 + '" x2="' + x2 + '" y2="' + y2 + '" stroke="var(--line2)" stroke-width="1"/>';
const tx = (x, y, t, a) => '<text x="' + x + '" y="' + y + '" font-size="9" fill="var(--muted)" text-anchor="' + (a || 'middle') + '">' + E(String(t).slice(0, 28)) + '</text>';

const T = window.__lab = {
  T: {}, order: [],
  add(cat, id, name, desc, fields, run, extra) {
    if (this.T[id]) return;
    this.T[id] = { id, cat, n: name, d: desc, f: fields || [], r: run, pre: extra && extra.pre, push: extra && extra.push, note: extra && extra.note };
    this.order.push(id);
  },
  E, N, num, pct, rows, tbl, kpi, bar, note, svg, ax, tx, clamp, col, today, days,
  state: () => { try { return JSON.parse(localStorage.getItem('sc-lab-state') || '{}'); } catch (e) { return {}; } },
  save(o) { try { localStorage.setItem('sc-lab-state', JSON.stringify(o)); } catch (e) {} },
  favs: () => { try { return JSON.parse(localStorage.getItem('sc-lab-favs') || '[]'); } catch (e) { return []; } },
  recent: () => { try { return JSON.parse(localStorage.getItem('sc-lab-recent') || '[]'); } catch (e) { return []; } }
};
const CATS = window.__lab.CATS = ['Favourites', 'Recent', 'Finance and valuation', 'Pricing and revenue', 'Marketing and growth', 'Risk and governance', 'Operations and supply', 'People and organisation', 'Data and technology', 'Strategy and portfolio', 'ESG and impact', 'Planning and delivery'];

/* ---------- generic field + result rendering ---------- */
function fieldHTML(f, v) {
  const val = v == null ? (f.d == null ? '' : f.d) : v;
  const lab = '<span>' + E(f.l) + '</span>';
  if (f.t === 't') return '<label class="lf">' + lab + '<textarea data-f="' + f.k + '" rows="' + (f.r || 4) + '">' + E(val) + '</textarea></label>';
  if (f.t === 's') return '<label class="lf">' + lab + '<select data-f="' + f.k + '">' + (f.o || []).map(o => '<option' + (String(o) === String(val) ? ' selected' : '') + '>' + E(o) + '</option>').join('') + '</select></label>';
  if (f.t === 'c') return '<label class="lf lfc"><input type="checkbox" data-f="' + f.k + '"' + (val ? ' checked' : '') + '>' + E(f.l) + '</label>';
  return '<label class="lf">' + lab + '<input data-f="' + f.k + '" value="' + E(val) + '" inputmode="decimal"></label>';
}
function readFields(root) {
  const v = {};
  $$('[data-f]', root).forEach(el => { v[el.dataset.f] = el.type === 'checkbox' ? el.checked : el.value; });
  return v;
}
function resultHTML(tool, v) {
  try { return tool.r(v) || ''; } catch (e) { return note('Could not compute with these values: ' + E(e.message)); }
}
function tableCSV(html) {
  const d = D.createElement('div'); d.innerHTML = html;
  const t = d.querySelector('table');
  if (!t) return [[(d.textContent || '').trim().replace(/\s+/g, ' ')]];
  return [...t.querySelectorAll('tr')].map(tr => [...tr.children].map(td => (td.textContent || '').trim()));
}
function download(name, text) {
  const u = URL.createObjectURL(new Blob([text], { type: 'text/csv;charset=utf-8' }));
  const l = D.createElement('a'); l.href = u; l.download = name; l.click();
  setTimeout(() => URL.revokeObjectURL(u), 2000);
}
function printHTML(title, html) {
  const f = D.createElement('iframe');
  f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
  D.body.appendChild(f);
  const doc = f.contentDocument;
  doc.open();
  doc.write('<!doctype html><html><head><meta charset="utf-8"><title>' + E(title) + '</title><style>body{font:13px/1.5 system-ui,sans-serif;padding:22px;color:#111}h1{font-size:20px}table{width:100%;border-collapse:collapse;margin:10px 0}th,td{padding:6px 8px;border-bottom:1px solid #ddd;text-align:left;vertical-align:top}th{background:#f3f4f6;font-size:11px;text-transform:uppercase;letter-spacing:.06em}.labkpi{display:flex;gap:10px;flex-wrap:wrap}.labkpi>div{border:1px solid #ddd;border-radius:8px;padding:8px 10px}.labbar{display:none}svg{max-width:100%}</style></head><body><h1>' + E(title) + '</h1>' + html + '</body></html>');
  doc.close();
  setTimeout(() => { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (e) {} setTimeout(() => f.remove(), 1500); }, 250);
}

/* ---------- Lab modal ---------- */
let cur = null, query = '';
function openLab(id) {
  const m = $('#labm'); if (m) m.remove();
  const d = D.createElement('div');
  d.id = 'labm'; d.className = 'pro-modal';
  d.innerHTML = '<div class="pro-box wide labbox"><button class="pro-x" aria-label="Close">x</button>' +
    '<div class="labhead"><div><span class="eyebrow">Strategy Cascade Lab</span><h2>Analysis tools</h2></div><input id="labq" type="search" placeholder="Search ' + T.order.length + ' tools" aria-label="Search tools"></div>' +
    '<div class="labwrap"><aside class="labside"><div id="labnav"></div></aside><section class="labmain" id="labmain"></section></div></div>';
  D.body.appendChild(d);
  requestAnimationFrame(() => d.classList.add('on'));
  const q = $('#labq', d);
  /* one delegated handler for the whole panel: re-rendering must not stack listeners */
  d.addEventListener('click', e => {
    if (e.target === d || e.target.closest('.pro-x')) { d.remove(); return; }
    const navBtn = e.target.closest('[data-tool]');
    if (navBtn) { cur = navBtn.dataset.tool; drawNav(); drawMain(); return; }
    const fv = e.target.closest('#labfav');
    if (fv) { toggleFav(fv); return; }
    const act = e.target.closest('[data-lab]');
    if (act) labAction(act.dataset.lab, act);
  });
  d.addEventListener('input', e => {
    if (e.target.id === 'labq') { query = e.target.value; drawNav(); }
    else if (e.target.closest('[data-f]')) runTool();
  });
  d.addEventListener('change', e => {
    if (e.target.id === 'labpush') pushTarget = e.target.value;
  });
  cur = id && T.T[id] ? id : (T.recent()[0] || T.order[0]);
  drawNav(); drawMain();
  setTimeout(() => q.focus(), 60);
}
function drawNav() {
  const nav = $('#labnav'); if (!nav) return;
  const q = query.trim().toLowerCase();
  const favs = T.favs(), rec = T.recent();
  const seen = new Set();
  let h = '';
  CATS.forEach(cat => {
    let ids;
    if (cat === 'Favourites') ids = favs.filter(id => T.T[id]);
    else if (cat === 'Recent') ids = rec.filter(id => T.T[id]).slice(0, 6);
    else ids = T.order.filter(id => T.T[id].cat === cat);
    if (q) {
      ids = ids.filter(id => (T.T[id].n + ' ' + T.T[id].d + ' ' + T.T[id].cat).toLowerCase().includes(q));
      /* a search should list each tool once, not again under Favourites and Recent */
      ids = ids.filter(id => { if (seen.has(id)) return false; seen.add(id); return true; });
    }
    if (!ids.length) return;
    h += '<div class="labcat">' + E(cat) + '</div>';
    h += ids.map(id => '<button class="labitem' + (id === cur ? ' on' : '') + '" data-tool="' + id + '">' + (favs.includes(id) ? '<i class="labstar">*</i>' : '') + E(T.T[id].n) + '</button>').join('');
  });
  if (!h) h = '<p class="muted" style="font-size:13px">No tool matches that search.</p>';
  nav.innerHTML = h;
}
function drawMain() {
  const box = $('#labmain'), tool = T.T[cur]; if (!box || !tool) return;
  const st = T.state()[cur] || {};
  const fav = T.favs().includes(cur);
  box.innerHTML = '<div class="labtitle"><div><h3>' + E(tool.n) + '</h3><p class="muted">' + E(tool.d) + '</p></div><button class="chip labfav' + (fav ? ' on' : '') + '" id="labfav" data-on="' + (fav ? '1' : '') + '" title="Add to favourites">' + (fav ? 'Saved' : 'Save') + '</button></div>' +
    '<div class="labfields">' + tool.f.map(f => fieldHTML(f, st[f.k])).join('') + '</div>' +
    (tool.pre ? '<div class="labacts"><button class="btn sm" data-lab="pre">Load from my plan</button><span class="muted" id="labprem" style="font-size:12px;align-self:center">Fills this tool with data already in the workspace.</span></div>' : '') +
    '<div id="labout"></div>' +
    (tool.push ? T.compSelect() : '') +
    '<div class="labacts"><button class="btn sm" data-lab="csv">Export CSV</button><button class="btn sm" data-lab="copy">Copy result</button><button class="btn sm" data-lab="print">Print</button><button class="btn sm" data-lab="reset">Reset inputs</button>' + (tool.push ? '<button class="btn sm pri" data-lab="push">Send to plan</button>' : '') + '</div>' +
    (tool.note ? note(tool.note) : '');
  runTool();
  const rec = T.recent().filter(x => x !== cur); rec.unshift(cur);
  try { localStorage.setItem('sc-lab-recent', JSON.stringify(rec.slice(0, 12))); } catch (e) {}
}
function labAction(k, btn) {
  const tool = T.T[cur], box = $('#labmain'), out = $('#labout');
  if (!tool || !box || !out) return;
  if (k === 'csv') {
    const name = cur + '-result.csv';
    download(name, tableCSV(out.innerHTML).map(r => r.map(c => '"' + String(c).replace(/"/g, '""') + '"').join(',')).join('\r\n'));
  } else if (k === 'copy') {
    const txt = (out.textContent || '').trim();
    if (navigator.clipboard) navigator.clipboard.writeText(txt).then(() => {
      if (!btn) return;
      btn.textContent = 'Copied';
      setTimeout(() => { btn.textContent = 'Copy result'; }, 1200);
    }).catch(() => {});
  } else if (k === 'print') {
    printHTML(tool.n, out.innerHTML);
  } else if (k === 'reset') {
    const s = T.state(); delete s[cur]; T.save(s); drawMain();
  } else if (k === 'pre') {
    const p = tool.pre && tool.pre();
    if (!p) { const msg = $('#labprem'); if (msg) msg.textContent = 'Nothing to load yet: this data is not in the workspace.'; return; }
    const s = T.state(); s[cur] = Object.assign({}, s[cur], p); T.save(s); drawMain();
    const msg = $('#labprem'); if (msg) msg.textContent = 'Loaded from the workspace.';
  } else if (k === 'push' && tool.push) {
    const sel = $('#labpush'); if (sel) pushTarget = sel.value;
    const n = tool.push(readFields(box));
    const a = A();
    if (a && a.toast) a.toast(n ? 'Sent ' + n + ' item' + (n === 1 ? '' : 's') + ' to the plan' : 'Pick a target component first');
  }
}
function toggleFav(fv) {
  const list = T.favs(); const i = list.indexOf(cur);
  if (i < 0) list.push(cur); else list.splice(i, 1);
  try { localStorage.setItem('sc-lab-favs', JSON.stringify(list)); } catch (e) {}
  fv.classList.toggle('on', i < 0);
  fv.dataset.on = i < 0 ? '1' : '';
  fv.textContent = i < 0 ? 'Saved' : 'Save';
  drawNav();
}
function runTool() {
  const box = $('#labmain'); if (!box) return;
  const tool = T.T[cur], out = $('#labout'); if (!tool || !out) return;
  const v = readFields(box);
  const s = T.state(); s[cur] = v; T.save(s);
  out.innerHTML = resultHTML(tool, v);
}

/* ---------- shared plan helpers for tools ---------- */
let pushTarget = '';
T.plan = () => {
  const a = A(); if (!a) return [];
  return a.ALLC.map(c => ({ c, d: a.getC(c.id) }));
};
T.pushRisks = (list) => {
  const a = A(); if (!a) return 0;
  const sel = $('#labpush'); if (!sel || !sel.value) return 0;
  const id = sel.value, d = a.getC(id), add = list.map(x => '- ' + x).filter(Boolean);
  if (!add.length) return 0;
  const prev = String(d.rk || '').trim();
  d.rk = prev ? prev + '\n' + add.join('\n') : add.join('\n');
  a.touch('c:' + id); a.render(); return add.length;
};
T.pushKpis = (list) => {
  const a = A(); if (!a) return 0;
  const sel = $('#labpush'); if (!sel || !sel.value) return 0;
  const id = sel.value, d = a.getC(id); let n = 0;
  list.forEach(k => {
    const name = String(k && k.k || '').trim(); if (!name) return;
    const hit = (d.kp || []).find(x => String(x.k || '').trim().toLowerCase() === name.toLowerCase());
    if (hit) {
      if (k.b != null) hit.b = String(k.b);
      if (k.t != null) hit.t = String(k.t);
      if (k.h != null) hit.h = String(k.h);
    } else {
      d.kp.push({ k: name, b: k.b == null ? '' : String(k.b), t: k.t == null ? '' : String(k.t), h: k.h == null ? '' : String(k.h) });
    }
    n++;
  });
  if (!n) return 0;
  a.touch('c:' + id); a.render(); return n;
};
T.pushDecisions = (list) => {
  const a = A(); if (!a) return 0;
  const sel = $('#labpush'); if (!sel || !sel.value) return 0;
  const id = sel.value, d = a.getC(id), add = list.map(x => '- ' + x).filter(Boolean);
  if (!add.length) return 0;
  const prev = String(d.dec || '').trim();
  d.dec = prev ? prev + '\n' + add.join('\n') : add.join('\n');
  a.touch('c:' + id); a.render(); return add.length;
};
T.compSelect = () => {
  const a = A(); if (!a) return '';
  const cur = pushTarget && a.BYID[pushTarget] ? pushTarget : (a.ALLC[0] ? a.ALLC[0].id : '');
  return '<div class="labpush"><label class="lf"><span>Send to component</span><select id="labpush">' +
    a.ALLC.map(c => '<option value="' + c.id + '"' + (c.id === cur ? ' selected' : '') + '>' + E(c.id + ' ' + c.short) + '</option>').join('') +
    '</select></label></div>';
};

/* ---------- native Analysis Lab page (uses the app shell, not a modal) ---------- */
let pageQ = '', pageCat = 'All';
function labCards() {
  const q = pageQ.trim().toLowerCase();
  const ids = T.order.filter(id => {
    const t = T.T[id];
    if (pageCat !== 'All' && t.cat !== pageCat) return false;
    return !q || (t.n + ' ' + t.d + ' ' + t.cat).toLowerCase().includes(q);
  });
  if (!ids.length) return '<p class="labnote" style="grid-column:1/-1">No tool matches that search.</p>';
  const favs = T.favs();
  return ids.map(id => {
    const t = T.T[id];
    return '<button class="card labcard" type="button" data-labopen="' + id + '">' +
      '<span class="labtag">' + E(t.cat) + '</span>' +
      '<h3>' + E(t.n) + '</h3>' +
      '<p>' + E(t.d) + '</p>' +
      '<span class="labmeta">' + (t.push ? '<em>Writes to plan</em>' : '') + (t.pre ? '<em>Loads your data</em>' : '') + (favs.includes(id) ? '<em>Saved</em>' : '') + '</span>' +
      '</button>';
  }).join('');
}
function vLabPage() {
  const total = T.order.length;
  const cats = T.CATS.filter(c => c !== 'Favourites' && c !== 'Recent');
  const pushes = T.order.filter(id => T.T[id].push).length;
  const pres = T.order.filter(id => T.T[id].pre).length;
  const favs = T.favs().length;
  const rec = T.recent().filter(id => T.T[id]).slice(0, 6);
  const chips = ['All'].concat(cats).map(c =>
    '<button type="button" class="chip' + (c === pageCat ? ' on' : '') + '" data-labcat="' + E(c) + '">' + E(c === 'All' ? 'All tools' : c) + '</button>').join('');
  return (typeof crumbs === 'function' ? crumbs([{ t: 'Overview', go: 'home' }, { t: 'Analysis Lab' }]) : '') +
    '<span class="eyebrow">Analysis Lab</span>' +
    '<h1 style="margin-top:6px">' + total + ' working tools, built on the same plan</h1>' +
    '<p class="lead">Calculators for finance, pricing, growth, risk, operations, people, data, strategy, ESG and delivery. Every tool recalculates as you type, exports to CSV and prints. ' + pres + ' tools read what is already in your workspace and ' + pushes + ' write their result back into a component, so the analysis and the plan never drift apart.</p>' +
    '<div class="kpis" style="margin-top:20px">' +
      '<section class="card kpi"><b>' + total + '</b><span>tools</span></section>' +
      '<section class="card kpi"><b>' + cats.length + '</b><span>categories</span></section>' +
      '<section class="card kpi"><b>' + pushes + '</b><span>write to the plan</span></section>' +
      '<section class="card kpi"><b>' + favs + '</b><span>saved</span></section>' +
    '</div>' +
    '<div class="scope"><button class="btn pri" type="button" data-labpage="panel">Open the quick panel</button><button class="btn" type="button" data-labpage="random">Surprise me</button><button class="btn" type="button" data-labpage="csv">Download the tool list (CSV)</button></div>' +
    (rec.length ? '<p class="labnote" style="margin-top:14px">Recent: ' + rec.map(id => '<a href="#" data-labopen="' + id + '">' + E(T.T[id].n) + '</a>').join(' &middot; ') + '</p>' : '') +
    '<section class="card panel" style="margin-top:18px"><div class="labpghead"><h2>Find a tool</h2><input id="labpageq" type="search" placeholder="Search ' + total + ' tools" value="' + E(pageQ) + '" aria-label="Search tools"></div>' +
      '<div class="labchips">' + chips + '</div>' +
      '<div class="labcards" id="labpagegrid">' + labCards() + '</div></section>' +
    '<p class="labnote">Keyboard: Ctrl or Cmd + K searches pages, levels, components and tools. Alt + L opens the quick panel from anywhere.</p>';
}
window.vLab = vLabPage;
D.addEventListener('input', e => {
  if (e.target && e.target.id === 'labpageq') {
    pageQ = e.target.value;
    const g = $('#labpagegrid'); if (g) g.innerHTML = labCards();
  }
});
D.addEventListener('click', e => {
  if (!e.target.closest) return;
  const cat = e.target.closest('[data-labcat]');
  if (cat) {
    e.preventDefault(); pageCat = cat.dataset.labcat;
    $$('[data-labcat]').forEach(b => b.classList.toggle('on', b.dataset.labcat === pageCat));
    const g = $('#labpagegrid'); if (g) g.innerHTML = labCards();
    return;
  }
  const card = e.target.closest('[data-labopen]');
  if (card) { e.preventDefault(); openLab(card.dataset.labopen); return; }
  const act = e.target.closest('[data-labpage]');
  if (act) {
    e.preventDefault();
    const k = act.dataset.labpage;
    if (k === 'panel') openLab();
    else if (k === 'random') openLab(T.order[Math.floor(Math.random() * T.order.length)]);
    else if (k === 'csv') {
      const head = 'Tool,Category,Description,Fields,Reads the plan,Writes to the plan\n';
      const body = T.order.map(id => {
        const t = T.T[id];
        return [t.n, t.cat, t.d, t.f.map(f => f.l).join(' / '), t.pre ? 'Yes' : 'No', t.push ? 'Yes' : 'No']
          .map(x => '"' + String(x == null ? '' : x).replace(/"/g, '""') + '"').join(',');
      }).join('\r\n');
      download('strategy-cascade-tools.csv', head + body);
    }
  }
});

/* ---------- command palette (Ctrl/Cmd+K) ---------- */
const PAGES = [['home', 'Overview'], ['domains', 'Domains'], ['outputs', 'Output center'], ['versions', 'Versions'], ['sources', 'Data sources'], ['toolkit', 'Finance toolkit'], ['budget', 'Campaign budget'], ['software', 'Software options'], ['review', 'Review and print']];
let palIdx = 0, palItems = [];
function palOpen() {
  const cp = $('#cp'); if (!cp) return;
  cp.classList.add('on');
  const i = $('#cpi'); if (i) { i.value = ''; setTimeout(() => i.focus(), 20); }
  palRender('');
}
function palClose() { const cp = $('#cp'); if (cp) cp.classList.remove('on'); }
function palRender(q) {
  const a = A(), t = q.trim().toLowerCase();
  const items = [];
  PAGES.forEach(p => items.push({ g: 'Page', t: p[1], m: '#' + p[0], go: p[0] }));
  if (a) (a.LV || window.__LV || []).forEach(l => items.push({ g: 'Level', t: 'Level ' + l.n + ' - ' + l.name, m: l.comps.length + ' components', go: l.id }));
  if (a) a.ALLC.forEach(c => items.push({ g: 'Component', t: c.id + ' ' + c.short, m: c.lv.name, go: c.id }));
  T.order.forEach(id => items.push({ g: 'Lab tool', t: T.T[id].n, m: T.T[id].cat, lab: id }));
  [['lab', 'Open the Lab'], ['tk', 'Open the Toolkit'], ['ins', 'Open cascade insights'], ['as', 'Open the assistant'], ['theme', 'Toggle dark mode'], ['print', 'Print this page']].forEach(x => items.push({ g: 'Action', t: x[1], m: '', act: x[0] }));
  palItems = items.filter(x => !t || (x.t + ' ' + x.g + ' ' + (x.m || '')).toLowerCase().includes(t)).slice(0, 40);
  if (!palItems.length) { $('#cpl').innerHTML = '<p class="muted" style="padding:10px 16px;font-size:13px">Nothing found.</p>'; return; }
  palIdx = clamp(palIdx, 0, palItems.length - 1);
  $('#cpl').innerHTML = palItems.map((x, i) => '<a href="#" data-i="' + i + '" class="' + (i === palIdx ? 'on' : '') + '"><span>' + E(x.t) + '</span><span class="cpm">' + E(x.g) + (x.m ? ' - ' + E(x.m) : '') + '</span></a>').join('');
}
function palRun(i) {
  const x = palItems[i]; if (!x) return;
  palClose();
  if (x.go) { const a = A(); if (a && a.go) a.go(x.go); else location.hash = x.go; }
  else if (x.lab) openLab(x.lab);
  else if (x.act === 'lab') { const a = A(); if (a && a.go) a.go('lab'); else openLab(); }
  else if (x.act === 'tk') { const b = $('#tkb'); if (b) b.click(); }
  else if (x.act === 'ins') { const b = $('#insb'); if (b) b.click(); }
  else if (x.act === 'as') { const b = $('#askc'); if (b) b.click(); }
  else if (x.act === 'theme') { const b = $('[data-act=theme]'); if (b) b.click(); }
  else if (x.act === 'print') window.print();
}
window.__lab.open = openLab;
window.__lab.palette = palOpen;
D.addEventListener('keydown', e => {
  const k = e.key.toLowerCase();
  if ((e.ctrlKey || e.metaKey) && k === 'k') { e.preventDefault(); const cp = $('#cp'); if (cp && cp.classList.contains('on')) palClose(); else palOpen(); return; }
  if (k === 'escape') { palClose(); const m = $('#labm'); if (m) m.remove(); return; }
  const cp = $('#cp');
  if (cp && cp.classList.contains('on')) {
    if (k === 'arrowdown') { e.preventDefault(); palIdx = Math.min(palItems.length - 1, palIdx + 1); palRender($('#cpi').value); }
    else if (k === 'arrowup') { e.preventDefault(); palIdx = Math.max(0, palIdx - 1); palRender($('#cpi').value); }
    else if (k === 'enter') { e.preventDefault(); palRun(palIdx); }
  }
});
D.addEventListener('input', e => {
  if (e.target && e.target.id === 'cpi') { palIdx = 0; palRender(e.target.value); }
});
D.addEventListener('click', e => {
  const cp = $('#cp');
  if (cp && e.target === cp) palClose();
  const b = e.target.closest ? e.target.closest('[data-act=palette]') : null;
  if (b) { e.preventDefault(); palOpen(); return; }
  const link = e.target.closest ? e.target.closest('#cpl a') : null;
  if (link) { e.preventDefault(); palRun(+link.dataset.i); }
});
})();
