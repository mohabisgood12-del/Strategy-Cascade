/* Strategy Cascade Lab - strategy, ESG and planning tools */
(() => {
'use strict';
const L = window.__lab; if (!L) return;
const { E, N, num, pct, rows, tbl, kpi, bar, note, svg, ax, tx, clamp, col } = L;

/* ---------------- strategy and portfolio ---------------- */
const S = 'Strategy and portfolio';

L.add(S, 'growthdecomp', 'Growth decomposition', 'Split revenue growth into volume, price and interaction effects.',
  [{ k: 'p0', l: 'Prior price', d: '100' }, { k: 'u0', l: 'Prior units', d: '10000' }, { k: 'p1', l: 'Current price', d: '108' }, { k: 'u1', l: 'Current units', d: '11200' }],
  v => {
    const p0 = N(v.p0), u0 = N(v.u0), p1 = N(v.p1), u1 = N(v.u1);
    const r0 = p0 * u0, r1 = p1 * u1, vol = (u1 - u0) * p0, price = (p1 - p0) * u0, inter = (p1 - p0) * (u1 - u0);
    return kpi([['Prior revenue', num(r0)], ['Current revenue', num(r1)], ['Growth', r0 ? pct((r1 - r0) / r0 * 100) : 'n/a'], ['Volume effect', num(vol)], ['Price effect', num(price)]]) +
      tbl(['Driver', 'Amount', 'Share of growth'], [['Volume', num(vol), (r1 - r0) ? pct(vol / (r1 - r0) * 100) : 'n/a'], ['Price', num(price), (r1 - r0) ? pct(price / (r1 - r0) * 100) : 'n/a'], ['Interaction', num(inter), (r1 - r0) ? pct(inter / (r1 - r0) * 100) : 'n/a'], ['<b>Total</b>', '<b>' + num(r1 - r0) + '</b>', '100%']]) +
      note('If growth is mostly price, it is fragile and easy for a competitor to undercut. Volume-led growth is more durable.');
  });

L.add(S, 'share', 'Market share model', 'Your share, the change since the prior period, and the sales needed to hit a target.',
  [{ k: 'sales', l: 'Your sales', d: '12000000' }, { k: 'market', l: 'Total market sales', d: '80000000' }, { k: 'prior', l: 'Your prior share %', d: '13' }, { k: 'target', l: 'Target share %', d: '18' }, { k: 'growth', l: 'Market growth %', d: '5' }],
  v => {
    const sales = N(v.sales), market = Math.max(1, N(v.market)), share = sales / market * 100, prior = N(v.prior), target = N(v.target) / 100;
    const marketNext = market * (1 + N(v.growth) / 100), need = marketNext * target;
    return kpi([['Current share', pct(share, 2)], ['Change', pct(share - prior, 2)], ['Target sales', num(need)], ['Sales gap', num(need - sales)]]) +
      tbl(['Metric', 'Value'], [['Your sales', num(sales)], ['Market', num(market)], ['Share', pct(share, 2)], ['Prior share', pct(prior, 2)], ['Share gain needed', pct(target * 100 - share, 2)], ['Market next year', num(marketNext)]]) +
      note('To reach ' + pct(target * 100) + ' you need ' + num(Math.max(0, need - sales)) + ' more sales, assuming the market grows ' + pct(N(v.growth)) + '.');
  });

L.add(S, 'position', 'Competitive positioning score', 'Weighted win/lose against a named competitor by criterion.',
  [{ k: 'them', l: 'Competitor name', d: 'Main rival' }, { k: 'v', l: 'One line per criterion: criterion|weight %|us 1-10|them 1-10', d: 'Price|25|6|8\nQuality|30|9|6\nService|25|8|7\nBrand|20|7|9', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Criterion', w: Math.max(0, N(x[1])), us: clamp(N(x[2]), 1, 10), th: clamp(N(x[3]), 1, 10) })).filter(x => x.n);
    if (!r.length) return note('Add at least one criterion: criterion|weight|us|them.');
    const tw = r.reduce((s, x) => s + x.w, 0) || 1;
    const us = r.reduce((s, x) => s + x.us * x.w, 0) / tw, th = r.reduce((s, x) => s + x.th * x.w, 0) / tw;
    const win = r.filter(x => x.us > x.th), lose = r.filter(x => x.us < x.th);
    return kpi([['Our score', num(us, 2)], [E(v.them || 'Competitor'), num(th, 2)], ['Lead', num(us - th, 2)], ['We win on', win.length + ' of ' + r.length]]) +
      tbl(['Criterion', 'Weight', 'Us', 'Them', 'Gap', 'Verdict'], r.map(x => [E(x.n), pct(x.w), num(x.us), num(x.th), '<span style="color:' + (x.us >= x.th ? '#2e9d62' : '#c9473d') + '">' + (x.us >= x.th ? '+' : '') + num(x.us - x.th) + '</span>', x.us > x.th ? 'Win' : x.us < x.th ? 'Lose' : 'Tie'])) +
      note('We lose on ' + lose.length + ' criteria, weighted ' + pct(lose.reduce((s, x) => s + x.w, 0)) + '. Fix the highest-weight loss before spending on the rest.');
  });

L.add(S, 'gemck', 'GE-McKinsey portfolio', 'Place business units on a nine-box matrix and get the invest, select or harvest call.',
  [{ k: 'v', l: 'One line per unit: unit|market attractiveness 1-5|competitive strength 1-5|sales', d: 'Core|4|5|40000000\nAdjacent|5|3|15000000\nLegacy|2|4|20000000\nNew|3|2|5000000', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Unit', a: clamp(N(x[1]), 1, 5), s: clamp(N(x[2]), 1, 5), sales: N(x[3]) })).filter(x => x.n);
    if (!r.length) return note('Add at least one unit: unit|attractiveness|strength|sales.');
    const cell = x => x.a >= 4 && x.s >= 4 ? ['Invest and grow', '#2e9d62'] : x.a <= 2 && x.s <= 2 ? ['Divest', '#c9473d'] : (x.a >= 4 && x.s <= 2) || (x.a <= 2 && x.s >= 4) ? ['Selective', '#d9922b'] : ['Build selectively', '#2e6bd9'];
    const W = 320, H = 300, pd = 38, X = s => pd + (W - 2 * pd) * (s - 1) / 4, Y = a => H - pd - (H - 2 * pd) * (a - 1) / 4;
    let grid = '';
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) grid += '<rect x="' + (pd + (W - 2 * pd) * i / 3) + '" y="' + (pd + (H - 2 * pd) * j / 3) + '" width="' + ((W - 2 * pd) / 3) + '" height="' + ((H - 2 * pd) / 3) + '" fill="' + (i === 2 && j === 0 ? 'rgba(46,157,98,.10)' : i === 0 && j === 2 ? 'rgba(201,71,61,.10)' : 'transparent') + '" stroke="var(--line)"/>';
    return kpi([['Units', r.length], ['Invest and grow', r.filter(x => cell(x)[0] === 'Invest and grow').length], ['Divest', r.filter(x => cell(x)[0] === 'Divest').length], ['Largest unit', E(r.slice().sort((a, b) => b.sales - a.sales)[0].n)]]) +
      svg(W, H, grid + ax(pd, H - pd, W - pd, H - pd) + ax(pd, pd, pd, H - pd) + tx(W / 2, H - 8, 'competitive strength') + tx(10, 20, 'market attractiveness', 'start') + r.map(x => '<circle cx="' + X(x.s) + '" cy="' + Y(x.a) + '" r="6" fill="' + cell(x)[1] + '" fill-opacity=".8"/><text x="' + (X(x.s) + 9) + '" y="' + (Y(x.a) + 3) + '" font-size="8.5" fill="var(--ink)">' + E(x.n.slice(0, 14)) + '</text>').join('')) +
      tbl(['Unit', 'Attractiveness', 'Strength', 'Sales', 'Call'], r.map(x => { const c = cell(x); return [E(x.n), x.a, x.s, num(x.sales), '<b style="color:' + c[1] + '">' + c[0] + '</b>']; })) +
      note('Invest where both axes are strong. Selectively build in the middle. Divest where attractiveness and strength are both weak.');
  });

L.add(S, 'initscore', 'Strategic initiative scoring', 'Rank initiatives on impact, confidence, ease and cost, and show value per unit of cost.',
  [{ k: 'v', l: 'One line per initiative: initiative|impact 1-5|confidence %|ease 1-5|cost', d: 'Pricing reset|5|70|4|200000\nNew segment|4|50|2|900000\nAutomation|3|80|3|300000', t: 't' }],
  v => {
    const r = rows(v.v).map(x => { const i = clamp(N(x[1]), 1, 5), c = clamp(N(x[2]), 0, 100), e = clamp(N(x[3]), 1, 5), cost = Math.max(1, N(x[4])); return { n: x[0] || 'Initiative', i, c, e, cost, sc: i * (c / 100) * (6 - e) / Math.log10(cost + 10) }; }).filter(x => x.n);
    if (!r.length) return note('Add at least one initiative: initiative|impact|confidence|ease|cost.');
    r.sort((a, b) => b.sc - a.sc);
    const max = r[0].sc || 1;
    return kpi([['Initiatives', r.length], ['Top priority', E(r[0].n)], ['Score', num(r[0].sc, 2)], ['Cheapest quick win', E(r.filter(x => x.e >= 4).sort((a, b) => a.cost - b.cost)[0] ? r.filter(x => x.e >= 4).sort((a, b) => a.cost - b.cost)[0].n : r[0].n)]]) +
      tbl(['Initiative', 'Impact', 'Confidence', 'Ease', 'Cost', 'Score', ''], r.map(x => [E(x.n), x.i, pct(x.c), x.e, num(x.cost), num(x.sc, 2), bar(x.sc / max * 100, '#2e6bd9')])) +
      note('Score = impact x confidence x ease, discounted by cost. High impact with low confidence is a hypothesis, not a plan.');
  });

L.add(S, 'maturity', 'Capability maturity assessment', 'Weighted current and target maturity and the size of the gap for each capability.',
  [{ k: 'v', l: 'One line per capability: capability|current 1-5|target 1-5|weight %', d: 'Strategy|3|4|25\nData|2|4|25\nOperations|4|4|20\nPeople|3|4|15\nTechnology|2|4|15', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Capability', cur: clamp(N(x[1]), 1, 5), tgt: clamp(N(x[2]), 1, 5), w: Math.max(0, N(x[3])) })).filter(x => x.n);
    if (!r.length) return note('Add at least one capability: capability|current|target|weight.');
    const tw = r.reduce((s, x) => s + x.w, 0) || 1;
    const cur = r.reduce((s, x) => s + x.cur * x.w, 0) / tw, tgt = r.reduce((s, x) => s + x.tgt * x.w, 0) / tw;
    r.forEach(x => x.gap = x.tgt - x.cur);
    r.sort((a, b) => b.gap * b.w - a.gap * a.w);
    return kpi([['Current maturity', num(cur, 2) + ' / 5'], ['Target maturity', num(tgt, 2) + ' / 5'], ['Gap', num(tgt - cur, 2)], ['Largest gap', E(r[0].n)]]) +
      tbl(['Capability', 'Current', 'Target', 'Gap', 'Weight', 'Priority', ''], r.map(x => [E(x.n), num(x.cur, 1), num(x.tgt, 1), num(x.gap, 1), pct(x.w), num(x.gap * x.w / tw, 2), bar(x.cur * 20, x.cur <= 2 ? '#c9473d' : '#2e9d62')])) +
      note('Sequence the largest weighted gaps first. Raising every capability at once is the most common way maturity programmes fail.');
  });

L.add(S, 'okralign', 'OKR alignment check', 'Progress, status and confidence for each key result, plus the objectives at risk.',
  [{ k: 'v', l: 'One line per key result: objective|key result|target|current|confidence %', d: 'Grow revenue|New ARR|5000000|3200000|70\nGrow revenue|Win rate|30|24|60\nDelight customers|NPS|60|52|80\nRun efficiently|Cost per order|12|13.5|50', t: 't' }],
  v => {
    const r = rows(v.v).map(x => { const t = N(x[2]), c = N(x[3]); return { o: x[0] || 'Objective', n: x[1] || 'Key result', t, c, conf: clamp(N(x[4]), 0, 100), p: t ? c / t * 100 : 0 }; }).filter(x => x.n);
    if (!r.length) return note('Add at least one key result: objective|key result|target|current|confidence.');
    const objs = {}; r.forEach(x => { (objs[x.o] = objs[x.o] || []).push(x); });
    const overall = r.reduce((s, x) => s + Math.min(100, x.p), 0) / r.length;
    return kpi([['Key results', r.length], ['Overall progress', pct(overall)], ['At risk', r.filter(x => x.conf < 60 || x.p < 50).length], ['Objectives', Object.keys(objs).length]]) +
      tbl(['Objective', 'Key result', 'Target', 'Current', 'Progress', 'Confidence', 'Status'], r.map(x => [E(x.o), E(x.n), num(x.t), num(x.c), pct(x.p), pct(x.conf), x.conf < 60 || x.p < 50 ? '<b style="color:#c9473d">At risk</b>' : x.p >= 100 ? '<b style="color:#2e9d62">Done</b>' : '<span style="color:#d9922b">On track</span>'])) +
      note('Objectives: ' + Object.keys(objs).map(k => E(k) + ' ' + num(objs[k].reduce((s, x) => s + Math.min(100, x.p), 0) / objs[k].length, 0) + '%').join('; ') + '.');
  }, {
  pre: () => { const a = window.__app; if (!a) return null; const out = []; a.ALLC.forEach(c => { const d = a.getC(c.id); (d.kp || []).forEach(k => { if (String(k.k).trim() && String(k.t).trim()) out.push((c.short || c.title) + '|' + k.k + '|' + k.t + '|' + (k.b || '0') + '|' + (d.st === 3 ? 90 : 50)); }); }); return out.length ? { v: out.slice(0, 30).join('\n') } : null; },
  push: v => { const list = rows(v.v).map(x => ({ k: x[1], b: x[3], t: x[2], h: 'Confidence ' + (x[4] || '') + '%' })).filter(x => String(x.k || '').trim()); return L.pushKpis(list); }
});

L.add(S, 'synergy', 'M&A synergy valuation', 'Present value of cost and revenue synergies against integration cost, with payback.',
  [{ k: 'cost', l: 'Cost synergies per year', d: '8000000' }, { k: 'rev', l: 'Revenue synergies per year', d: '3000000' }, { k: 'integ', l: 'One-off integration cost', d: '12000000' }, { k: 'r', l: 'Discount rate %', d: '10' }, { k: 'y', l: 'Years of synergy', d: '5' }, { k: 'g', l: 'Terminal growth %', d: '2' }],
  v => {
    const s = N(v.cost) + N(v.rev), integ = N(v.integ), r = N(v.r) / 100, y = Math.max(1, N(v.y)), g = N(v.g) / 100;
    let pv = 0, cum = -integ, pb = null;
    for (let i = 1; i <= y; i++) { const disc = Math.pow(1 + r, i); pv += s / disc; cum += s; if (pb === null && cum >= 0) pb = i; }
    const tv = r > g ? s * (1 + g) / (r - g) / Math.pow(1 + r, y) : 0;
    const npv = pv + tv - integ;
    return kpi([['Annual synergy', num(s)], ['PV of synergies', num(pv + tv)], ['Integration cost', num(integ)], ['Net value', num(npv)], ['Payback', pb ? pb + ' years' : 'not reached']]) +
      tbl(['Component', 'Value'], [['Cost synergies', num(N(v.cost))], ['Revenue synergies', num(N(v.rev))], ['PV of explicit years', num(pv)], ['PV of terminal value', num(tv)], ['Less integration cost', '-' + num(integ)], ['<b>Net value</b>', '<b>' + num(npv) + '</b>']]) +
      note(npv > 0 ? 'The deal creates value on these assumptions. Most synergies are overstated, so test a case at 50% of plan.' : 'The synergies do not cover the integration cost. Re-cut the price or the scope.');
  });

/* ---------------- ESG and impact ---------------- */
const G = 'ESG and impact';

L.add(G, 'carbon', 'Carbon footprint', 'Convert activity data into tonnes of CO2e and show the split by scope.',
  [{ k: 'v', l: 'One line per source: source|scope (1/2/3)|quantity|emission factor kg CO2e per unit', d: 'Gas boilers|1|120000|0.18\nElectricity|2|800000|0.4\nBusiness travel|3|350000|0.15\nPurchased goods|3|900000|0.6', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Source', sc: clamp(N(x[1]), 1, 3), q: N(x[2]), f: N(x[3]) })).filter(x => x.n);
    if (!r.length) return note('Add at least one source: source|scope|quantity|factor.');
    r.forEach(x => x.t = x.q * x.f / 1000);
    const total = r.reduce((s, x) => s + x.t, 0);
    const by = [1, 2, 3].map(s => r.filter(x => x.sc === s).reduce((a, x) => a + x.t, 0));
    return kpi([['Total emissions', num(total, 1) + ' tCO2e'], ['Scope 1', num(by[0], 1)], ['Scope 2', num(by[1], 1)], ['Scope 3', num(by[2], 1)]]) +
      tbl(['Source', 'Scope', 'Quantity', 'Factor', 'tCO2e', 'Share'], r.map(x => [E(x.n), x.sc, num(x.q), num(x.f, 2), num(x.t, 1), pct(total ? x.t / total * 100 : 0)])) +
      note('Scope 3 is usually the largest and the hardest to measure. Use supplier-specific factors where you can, and state the method.');
  });

L.add(G, 'netzero', 'Net-zero pathway', 'Year-by-year emissions under a reduction rate, the year the target is met, and the residual to remove.',
  [{ k: 'base', l: 'Baseline emissions (tCO2e)', d: '10000' }, { k: 'year', l: 'Baseline year', d: '2025' }, { k: 'target', l: 'Target year', d: '2040' }, { k: 'red', l: 'Annual reduction %', d: '8' }, { k: 'rem', l: 'Removals per year (tCO2e)', d: '500' }],
  v => {
    const base = N(v.base), y0 = N(v.year), yt = N(v.target), red = N(v.red) / 100, rem = N(v.rem);
    const rs = []; let e = base, hit = null;
    for (let y = y0; y <= Math.max(yt, y0 + 1); y++) {
      if (y > y0) e = Math.max(0, e * (1 - red));
      const net = Math.max(0, e - rem);
      if (hit === null && net <= 0) hit = y;
      rs.push([y, num(e, 1), num(rem), num(net, 1), net <= 0 ? '<b style="color:#2e9d62">Net zero</b>' : '']);
    }
    const atTarget = Math.max(0, e - rem);
    return kpi([['Emissions at target year', num(atTarget, 1)], ['Reduction from base', base ? pct((base - atTarget) / base * 100) : 'n/a'], ['Net zero reached', hit || 'after ' + yt], ['Residual to remove', num(atTarget, 1)]]) +
      tbl(['Year', 'Gross emissions', 'Removals', 'Net', 'Status'], rs) +
      note(hit ? 'The pathway reaches net zero in ' + hit + '.' : 'The pathway does not reach net zero by ' + yt + '. Increase the reduction rate or buy more removals.');
  });

L.add(G, 'sroi', 'Social return on investment', 'Adjust outcome value for attribution and deadweight, then compare with the investment.',
  [{ k: 'inv', l: 'Total investment', d: '500000' }, { k: 'v', l: 'One line per outcome: outcome|annual value|attribution %|deadweight %', d: 'Employment|800000|60|30\nHealth|300000|50|20\nSkills|200000|70|40', t: 't' }],
  v => {
    const inv = Math.max(1, N(v.inv));
    const r = rows(v.v).map(x => { const val = N(x[1]), a = N(x[2]) / 100, d = N(x[3]) / 100; return { n: x[0] || 'Outcome', val, a, d, adj: val * a * (1 - d) }; }).filter(x => x.n);
    if (!r.length) return note('Add at least one outcome: outcome|value|attribution|deadweight.');
    const total = r.reduce((s, x) => s + x.adj, 0), ratio = total / inv;
    return kpi([['Adjusted value', num(total)], ['Investment', num(inv)], ['SROI ratio', num(ratio, 2) + ' : 1'], ['Net value', num(total - inv)]]) +
      tbl(['Outcome', 'Value', 'Attribution', 'Deadweight', 'Adjusted'], r.map(x => [E(x.n), num(x.val), pct(x.a * 100), pct(x.d * 100), num(x.adj)])) +
      note('An SROI of ' + num(ratio, 2) + ' means each unit invested returns ' + num(ratio, 2) + ' in adjusted social value. Attribution and deadweight assumptions must be documented.');
  });

L.add(G, 'intensity', 'Energy and resource intensity', 'Normalise energy, water and waste by revenue and by unit of output, with a year-on-year comparison.',
  [{ k: 'kwh', l: 'Energy use (kWh)', d: '4200000' }, { k: 'water', l: 'Water use (m3)', d: '18000' }, { k: 'waste', l: 'Waste (tonnes)', d: '900' }, { k: 'rev', l: 'Revenue', d: '24000000' }, { k: 'units', l: 'Units produced', d: '600000' }, { k: 'prev', l: 'Prior year revenue', d: '22000000' }, { k: 'prevkwh', l: 'Prior year energy (kWh)', d: '4400000' }],
  v => {
    const kwh = N(v.kwh), water = N(v.water), waste = N(v.waste), rev = Math.max(1, N(v.rev)), units = Math.max(1, N(v.units));
    const ei = kwh / rev * 1000, wi = water / rev * 1000, ui = kwh / units, prev = N(v.prevkwh), prevRev = Math.max(1, N(v.prev));
    const prevInt = prev / prevRev * 1000;
    return kpi([['Energy per revenue', num(ei, 2) + ' kWh / 1k'], ['Energy per unit', num(ui, 3) + ' kWh'], ['Water per revenue', num(wi, 2) + ' m3 / 1k'], ['Waste per unit', num(waste / units * 1000, 2) + ' kg']]) +
      tbl(['Metric', 'Value'], [['Energy intensity', num(ei, 2)], ['Prior energy intensity', num(prevInt, 2)], ['Change', prevInt ? pct((ei - prevInt) / prevInt * 100) : 'n/a'], ['Water intensity', num(wi, 2)], ['Waste intensity', num(waste / units * 1000, 2) + ' kg/unit'], ['Verdict', ei <= prevInt ? '<b style="color:#2e9d62">Improving</b>' : '<b style="color:#c9473d">Worsening</b>']]) +
      note('Absolute emissions can rise while intensity falls if you grow. Report both so the picture is honest.');
  });

/* ---------------- planning and delivery ---------------- */
const D = 'Planning and delivery';
const scopeMax = s => /all/i.test(s || '') ? 999 : /1-5/.test(s || '') ? 5 : /1-2/.test(s || '') ? 2 : 1;
const startDate = s => { const t = String(s || ''); return /^\d{4}-\d{2}-\d{2}$/.test(t) && isFinite(Date.parse(t)) ? t : L.today(); };
const planScope = (v) => {
  const a = window.__app; if (!a) return [];
  const max = scopeMax(v && v.scope);
  return a.ALLC.map(c => ({ c, d: a.getC(c.id) })).filter(x => x.d.st !== 3 && x.c.lv.n <= max);
};

L.add(D, 'plan90', '90-day plan generator', 'Build three 30-day sprints from the components in your workspace, ordered by status and due date.', [
  { k: 'goal', l: 'Goal for the quarter', d: 'Move every critical component to approved' },
  { k: 'scope', l: 'Scope', t: 's', o: ['Level 1 only', 'Levels 1-2', 'Levels 1-5', 'All levels'], d: 'Levels 1-2' },
  { k: 'owner', l: 'Plan owner', d: '' },
  { k: 'start', l: 'Start date', d: '' }
], v => {
    const a = window.__app;
    if (!a) return note('Open the Lab inside the app so it can read your plan.');
    const items = planScope(v);
    if (!items.length) return note('Every component in this scope is approved. Widen the scope or set some back to in progress.');
    items.sort((x, y) => (y.d.st === 4 ? 3 : y.d.st) - (x.d.st === 4 ? 3 : x.d.st) || String(x.d.due || '9999').localeCompare(String(y.d.due || '9999')));
    const third = Math.ceil(items.length / 3);
    const sprints = [items.slice(0, third), items.slice(third, third * 2), items.slice(third * 2)];
    const s0 = startDate(v.start);
    const add = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x.toISOString().slice(0, 10); };
    const rs = [];
    sprints.forEach((g, i) => g.forEach((x, j) => rs.push([i + 1, add(s0, i * 30) + ' to ' + add(s0, (i + 1) * 30 - 1), x.c.id, E(x.c.short || x.c.title), a.ST[x.d.st], x.d.owner || v.owner || 'Unassigned', j === 0 && i === 0 ? '<b>Start here</b>' : ''])));
    return kpi([['Scope', E(v.scope || 'Level 1 only')], ['Open components', items.length], ['Sprints', 3], ['Blocked', items.filter(x => x.d.st === 4).length]]) +
      tbl(['Sprint', 'Dates', 'ID', 'Component', 'Status', 'Owner', ''], rs) +
      note('Sprints are ordered so blocked and in-progress work comes first. Confirm owners and dates in the room; this is a starting point, not a decision.');
  }, {
  pre: () => { const a = window.__app; if (!a) return null; const m = a.S && a.S.meta; return { owner: (m && m.owner) || '', goal: 'Approve every critical component in ' + ((m && m.company) || 'the plan') }; },
  push: v => {
    const a = window.__app; if (!a) return 0;
    const items = planScope(v);
    if (!items.length) return 0;
    items.sort((x, y) => (y.d.st === 4 ? 3 : y.d.st) - (x.d.st === 4 ? 3 : x.d.st) || String(x.d.due || '9999').localeCompare(String(y.d.due || '9999')));
    const third = Math.ceil(items.length / 3);
    const groups = [items.slice(0, third), items.slice(third, third * 2), items.slice(third * 2)];
    const s0 = startDate(v.start);
    const add = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x.toISOString().slice(0, 10); };
    let n = 0;
    groups.forEach((g, i) => g.forEach(x => {
      x.d.due = add(s0, (i + 1) * 30 - 1);
      if (String(v.owner || '').trim()) x.d.owner = String(v.owner).trim();
      a.touch('c:' + x.c.id); n++;
    }));
    a.render(); return n;
  }
});

L.add(D, 'gantt', 'Milestone Gantt', 'Draw a timeline of tasks and milestones from start and end dates.',
  [{ k: 'v', l: 'One line per task: task|start YYYY-MM-DD|end YYYY-MM-DD', d: 'Diagnose|2026-11-01|2026-11-14\nDesign|2026-11-10|2026-12-05\nBuild|2026-12-01|2027-01-20\nLaunch|2027-01-21|2027-01-28', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Task', s: Date.parse(x[1]), e: Date.parse(x[2]) })).filter(x => x.n && isFinite(x.s) && isFinite(x.e) && x.e >= x.s);
    if (!r.length) return note('Add at least one task: task|start date|end date.');
    const min = Math.min(...r.map(x => x.s)), max = Math.max(...r.map(x => x.e)), span = Math.max(1, max - min);
    const W = 460, H = 34 + r.length * 26, left = 100, right = W - 14;
    const X = t => left + (right - left) * (t - min) / span;
    return kpi([['Tasks', r.length], ['Start', new Date(min).toISOString().slice(0, 10)], ['End', new Date(max).toISOString().slice(0, 10)], ['Days', Math.ceil(span / 864e5)]]) +
      svg(W, H, r.map((x, i) => { const y = 22 + i * 26; return '<text x="4" y="' + (y + 8) + '" font-size="8.5" fill="var(--ink)">' + E(x.n.slice(0, 16)) + '</text><rect x="' + X(x.s) + '" y="' + y + '" width="' + Math.max(2, X(x.e) - X(x.s)) + '" height="12" rx="3" fill="var(--l1)" fill-opacity=".8"/>'; }).join('') + ax(left, 10, left, H - 6) + tx(left, H - 2, new Date(min).toISOString().slice(0, 10), 'start') + tx(right, H - 2, new Date(max).toISOString().slice(0, 10), 'end')) +
      tbl(['Task', 'Start', 'End', 'Days'], r.map(x => [E(x.n), new Date(x.s).toISOString().slice(0, 10), new Date(x.e).toISOString().slice(0, 10), Math.ceil((x.e - x.s) / 864e5)]));
  }, {
  pre: () => { const a = window.__app; if (!a) return null; const out = []; a.ALLC.forEach(c => { const d = a.getC(c.id); if (d.due && d.st !== 3) out.push((c.short || c.title) + '|' + L.today() + '|' + d.due); }); return out.length ? { v: out.slice(0, 20).join('\n') } : null; }
});

L.add(D, 'reshist', 'Resource histogram', 'Weekly allocation by person, with overloaded weeks and the peak.',
  [{ k: 'v', l: 'One line per person: person|weekly allocation % comma separated', d: 'Ana|100,100,80,60\nBen|50,80,120,100\nChen|100,100,100,100', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Person', a: String(x[1] || '').split(',').map(N) })).filter(x => x.n);
    if (!r.length) return note('Add at least one person: person|allocation by week.');
    const weeks = Math.max(...r.map(x => x.a.length));
    const totals = Array.from({ length: weeks }, (_, i) => r.reduce((s, x) => s + (x.a[i] || 0), 0));
    const peak = Math.max(...totals), W = 420, H = 180, pd = 28, max = Math.max(100, peak);
    return kpi([['People', r.length], ['Weeks', weeks], ['Peak load', num(peak) + '%'], ['Overloaded weeks', totals.filter(x => x > 100 * r.length).length]]) +
      svg(W, H, ax(pd, H - pd, W - pd, H - pd) + totals.map((t, i) => { const bw = (W - pd * 2) / weeks; const h = (H - pd - 12) * t / max; return '<rect x="' + (pd + i * bw + 3) + '" y="' + (H - pd - h) + '" width="' + (bw - 6) + '" height="' + h + '" rx="2" fill="' + (t > 100 * r.length ? '#c9473d' : '#2e6bd9') + '" fill-opacity=".8"/>' + tx(pd + i * bw + bw / 2, H - pd + 13, 'W' + (i + 1)); }).join('')) +
      tbl(['Person', ...Array.from({ length: weeks }, (_, i) => 'W' + (i + 1)), 'Peak'], r.map(x => [E(x.n), ...x.a.map(v2 => v2 > 100 ? '<b style="color:#c9473d">' + v2 + '</b>' : num(v2)), num(Math.max(...x.a))])) +
      note('A person above 100% in any week is over-allocated. Total capacity is ' + num(100 * r.length) + '% per week.');
  }, {
  pre: () => { const a = window.__app; if (!a) return null; const o = {}; a.ALLC.forEach(c => { const d = a.getC(c.id); if (d.owner && d.st !== 3) o[d.owner] = (o[d.owner] || 0) + 1; }); const out = Object.keys(o).map(k => k + '|' + Array.from({ length: 6 }, (_, i) => Math.min(100, o[k] * 20)).join(',')); return out.length ? { v: out.join('\n') } : null; }
});

L.add(D, 'decisionlog', 'Decision log rollup', 'Open decisions, ageing, owners and the count by status.',
  [{ k: 'v', l: 'One line per decision: decision|date YYYY-MM-DD|owner|status (open/decided/deferred)|impact', d: 'Enter segment X|2026-09-01|CEO|open|High\nRebrand|2026-08-15|CMO|decided|Medium\nPrice rise|2026-10-01|CFO|open|High', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Decision', d: x[1] || '', own: x[2] || '', st: (x[3] || 'open').toLowerCase(), imp: x[4] || '', age: L.days(x[1]) != null ? -L.days(x[1]) : null })).filter(x => x.n);
    if (!r.length) return note('Add at least one decision: decision|date|owner|status|impact.');
    const open = r.filter(x => x.st === 'open'), avg = open.length ? open.reduce((s, x) => s + (x.age || 0), 0) / open.length : 0;
    return kpi([['Decisions', r.length], ['Open', open.length], ['Decided', r.filter(x => x.st === 'decided').length], ['Average age of open', num(avg) + ' days'], ['Oldest open', open.length ? E(open.slice().sort((a, b) => (b.age || 0) - (a.age || 0))[0].n) : '-']]) +
      tbl(['Decision', 'Date', 'Owner', 'Status', 'Impact', 'Age'], r.map(x => [E(x.n), E(x.d), E(x.own), E(x.st), E(x.imp), x.age == null ? '-' : num(x.age) + ' days'])) +
      note('An open decision older than 30 days is a governance problem, not a scheduling one. Escalate or close it.');
  }, {
  pre: () => { const a = window.__app; if (!a) return null; const out = []; a.ALLC.forEach(c => { const d = a.getC(c.id); if (d.st === 3) out.push((c.short || c.title) + '|' + (d.ad || d.due || L.today()) + '|' + (d.owner || '') + '|decided|Approved'); else if (d.st === 4) out.push((c.short || c.title) + '|' + (d.due || L.today()) + '|' + (d.owner || '') + '|open|Blocked'); }); return out.length ? { v: out.slice(0, 30).join('\n') } : null; },
  push: v => { const list = rows(v.v).filter(x => String(x[3] || 'open').toLowerCase() === 'open').map(x => (x[0] || '') + ' - owner ' + (x[2] || 'unassigned') + ', open since ' + (x[1] || 'unknown') + ', impact ' + (x[4] || 'unrated')); return L.pushDecisions(list); }
});

L.add(D, 'cadence', 'Meeting cadence planner', 'Monthly hours and cost of the meeting calendar, and where to cut.',
  [{ k: 'v', l: 'One line per meeting: meeting|frequency (weekly/fortnightly/monthly/quarterly)|minutes|attendees', d: 'Exec committee|weekly|90|8\nPortfolio review|fortnightly|120|14\nAll hands|monthly|60|200\nBoard|quarterly|240|10', t: 't' }, { k: 'rate', l: 'Fully loaded cost per hour per person', d: '85' }],
  v => {
    const per = f => /week/i.test(f) ? 52 / 12 : /fortnight/i.test(f) ? 26 / 12 : /quarter/i.test(f) ? 4 / 12 : /month/i.test(f) ? 1 : 1;
    const r = rows(v.v).map(x => ({ n: x[0] || 'Meeting', f: x[1] || 'monthly', m: N(x[2]), a: N(x[3]), h: N(x[2]) / 60 * N(x[3]) * per(x[1] || 'monthly') })).filter(x => x.n);
    if (!r.length) return note('Add at least one meeting: meeting|frequency|minutes|attendees.');
    const hours = r.reduce((s, x) => s + x.h, 0), cost = hours * N(v.rate);
    r.sort((a, b) => b.h - a.h);
    return kpi([['Meetings', r.length], ['Person-hours / month', num(hours)], ['Cost / month', num(cost)], ['Cost / year', num(cost * 12)]]) +
      tbl(['Meeting', 'Frequency', 'Minutes', 'Attendees', 'Hours / month', 'Cost / month'], r.map(x => [E(x.n), E(x.f), num(x.m), num(x.a), num(x.h, 1), num(x.h * N(v.rate))])) +
      note('The largest meeting is ' + E(r[0].n) + '. Halving its length saves ' + num(r[0].h * N(v.rate) * 6) + ' a year.');
  });

L.add(D, 'benefits', 'Benefits realisation tracker', 'Compare realised benefits with target and value, and show the gap.',
  [{ k: 'v', l: 'One line per benefit: benefit|baseline|target|current|annual value', d: 'Cost saving|0|2000000|1400000|2000000\nRevenue uplift|0|5000000|2100000|5000000\nChurn reduction|8|5|6.2|1200000', t: 't' }],
  v => {
    const r = rows(v.v).map(x => { const b = N(x[1]), t = N(x[2]), c = N(x[3]), val = N(x[4]); const prog = t !== b ? (c - b) / (t - b) * 100 : (c >= t ? 100 : 0); return { n: x[0] || 'Benefit', b, t, c, val, prog, realised: val * clamp(prog, 0, 150) / 100 }; }).filter(x => x.n);
    if (!r.length) return note('Add at least one benefit: benefit|baseline|target|current|annual value.');
    const target = r.reduce((s, x) => s + x.val, 0), got = r.reduce((s, x) => s + x.realised, 0);
    return kpi([['Target value', num(target)], ['Realised value', num(got)], ['Realisation', target ? pct(got / target * 100) : 'n/a'], ['Gap', num(target - got)]]) +
      tbl(['Benefit', 'Baseline', 'Target', 'Current', 'Progress', 'Value / year', 'Realised'], r.map(x => [E(x.n), num(x.b), num(x.t), num(x.c), pct(x.prog), num(x.val), num(x.realised)])) +
      note('Progress is measured from baseline to target. A benefit at 120% is capped at its stated value; check the business case before claiming more.');
  }, {
  pre: () => { const a = window.__app; if (!a) return null; const out = []; a.ALLC.forEach(c => { const d = a.getC(c.id); (d.kp || []).forEach(k => { if (String(k.k).trim() && String(k.t).trim()) out.push(k.k + '|' + (k.b || '0') + '|' + k.t + '|' + (k.b || '0') + '|0'); }); }); return out.length ? { v: out.slice(0, 25).join('\n') } : null; },
  push: v => { const list = rows(v.v).map(x => ({ k: x[0], b: x[1], t: x[2], h: 'Annual value ' + (x[4] || '0') })).filter(x => String(x.k || '').trim()); return L.pushKpis(list); }
});
})();
