/* Strategy Cascade Lab - styles, launcher and shortcuts */
(() => {
'use strict';
const D = document, $ = s => D.querySelector(s), L = window.__lab;

const css = `
/* command palette: the markup existed but had no positioning or hidden state */
#cp{position:fixed;inset:0;z-index:150;display:none;place-items:start center;padding:12vh 16px 16px;background:rgba(6,7,9,.55);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px)}
#cp.on{display:grid}
#cp>div{width:min(680px,96vw)!important;max-height:70vh;overflow:auto;border:1px solid var(--line2);background:var(--surface);box-shadow:0 30px 80px -20px rgba(0,0,0,.7)}
#cp input{width:100%!important;box-sizing:border-box}
#cp a{display:flex;gap:12px;align-items:center;text-decoration:none;font-size:13.5px}
#cp a.on{background:var(--surface2)!important}
#cp .cpm{margin-left:auto;color:var(--muted);font-size:11px;white-space:nowrap}
#cp .cph{padding:8px 16px 4px;font:600 10.5px var(--mono);text-transform:uppercase;letter-spacing:.09em;color:var(--muted)}
/* lab */
.labbox{width:min(1080px,97vw)!important}
.labhead{display:flex;align-items:flex-end;gap:14px;justify-content:space-between;flex-wrap:wrap;padding-right:40px}
.labhead h2{margin:2px 0 0}
.labhead input{min-width:220px;flex:1;max-width:320px;padding:9px 12px;border:1px solid var(--line2);border-radius:9px;background:var(--surface2)}
.labwrap{display:grid;grid-template-columns:250px minmax(0,1fr);gap:20px;margin-top:16px}
.labside{max-height:64vh;overflow:auto;padding-right:6px;border-right:1px solid var(--line)}
.labcat{font:600 10.5px var(--mono);text-transform:uppercase;letter-spacing:.09em;color:var(--muted);margin:12px 0 4px}
.labcat:first-child{margin-top:0}
.labitem{display:flex;gap:6px;align-items:center;width:100%;text-align:left;border:0;background:transparent;color:var(--ink);padding:7px 9px;border-radius:8px;cursor:pointer;font-size:13px;line-height:1.3}
.labitem:hover{background:var(--surface2)}
.labitem.on{background:var(--surface2);font-weight:600}
.labstar{color:#d9922b;font-style:normal;font-size:11px}
.labmain{min-width:0}
.labtitle{display:flex;gap:12px;justify-content:space-between;align-items:flex-start}
.labtitle h3{font-size:18px;margin:0 0 3px}
.labtitle p{font-size:13px;max-width:70ch}
.labfields{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px;margin:14px 0}
.labfields .lf{display:block;font-size:12px;color:var(--muted)}
.labfields .lf span{display:block;margin-bottom:4px}
.labfields input,.labfields select,.labfields textarea{width:100%;padding:8px 10px;border:1px solid var(--line2);border-radius:8px;background:var(--surface);color:var(--ink);font-size:13.5px}
.labfields textarea{font-family:var(--mono);font-size:12.5px;min-height:74px;resize:vertical}
.labfields .lf:has(textarea){grid-column:1/-1}
.labfields .lfc{display:flex;align-items:center;gap:8px;color:var(--ink)}
.labfields .lfc input{width:auto}
.labtbl{overflow:auto;margin:10px 0;border:1px solid var(--line);border-radius:10px}
.labtbl table{width:100%;border-collapse:collapse;font-size:13px}
.labtbl th{text-align:left;padding:7px 10px;border-bottom:1px solid var(--line2);font:600 10.5px var(--mono);text-transform:uppercase;letter-spacing:.06em;color:var(--muted);white-space:nowrap}
.labtbl td{padding:7px 10px;border-bottom:1px solid var(--line);vertical-align:top}
.labtbl tr:last-child td{border-bottom:0}
.labtbl tbody tr:hover td{background:var(--surface2)}
.labtbl tfoot td{font-weight:600;border-top:1px solid var(--line2)}
.labbar{display:block;height:6px;border-radius:99px;background:var(--line);overflow:hidden;min-width:60px}
.labbar i{display:block;height:100%;background:var(--l1)}
.labkpi{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px;margin:12px 0}
.labkpi>div{background:var(--surface2);border:1px solid var(--line);border-radius:10px;padding:9px 11px}
.labkpi b{display:block;font:700 17px/1.2 var(--display);letter-spacing:-.01em}
.labkpi span{font-size:10.5px;color:var(--muted);text-transform:uppercase;letter-spacing:.05em}
.labnote{font-size:12px;color:var(--muted);margin-top:10px;max-width:80ch}
.labacts{display:flex;gap:6px;flex-wrap:wrap;margin-top:12px;align-items:center}
.labsvg{width:100%;max-height:340px;margin:8px 0;border:1px solid var(--line);border-radius:10px;background:var(--surface2)}
.labpush{max-width:340px;margin:10px 0}
.labpush .lf{display:block;font-size:12px;color:var(--muted)}
.labpush .lf span{display:block;margin-bottom:4px}
.labpush select{width:100%;padding:8px 10px;border:1px solid var(--line2);border-radius:8px;background:var(--surface);color:var(--ink);font-size:13.5px}
.labfav.on{background:var(--surface2);border-color:var(--line2)}
/* native Lab page */
.labpghead{display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap;margin:0 0 12px}
.labpghead h2{font-size:15px;margin:0}
.labpghead input{flex:1;min-width:220px;max-width:320px;padding:9px 12px;border:1px solid var(--line2);border-radius:9px;background:var(--surface2);color:var(--ink);font-size:13.5px}
.labchips{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 14px}
.labchips .chip{font-size:12px;padding:5px 11px}
.labcards{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:12px}
.labcard{display:flex;flex-direction:column;gap:6px;text-align:left;padding:14px 16px;cursor:pointer;color:var(--ink);font:inherit;transition:transform .15s,border-color .15s,background .15s}
.labcard:hover{transform:translateY(-2px);border-color:var(--line2);background:var(--surface2)}
.labcard h3{margin:0;font-size:14.5px;line-height:1.3}
.labcard p{margin:0;font-size:12.5px;color:var(--muted);line-height:1.45}
.labtag{font:500 10px var(--mono);text-transform:uppercase;letter-spacing:.08em;color:var(--muted)}
.labmeta{display:flex;gap:6px;flex-wrap:wrap;margin-top:2px}
.labmeta em{font-style:normal;font-size:10.5px;padding:2px 7px;border-radius:999px;border:1px solid var(--line2);color:var(--muted)}
@media(max-width:820px){.labwrap{grid-template-columns:1fr}.labside{max-height:180px;border-right:0;border-bottom:1px solid var(--line);padding-bottom:8px}}
`;

const st = D.createElement('style');
st.textContent = css;
D.head.appendChild(st);

/* launcher button in the top bar */
function launcher() {
  const bar = D.querySelector('.top'); if (!bar || $('#labbtn')) return;
  const anchor = $('#tkb') || $('#insb') || $('#askc');
  const b = D.createElement('button');
  b.className = 'ibtn'; b.id = 'labbtn'; b.title = 'Analysis Lab (Alt+L)';
  b.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 2 3h10a2 2 0 0 0 2-3l-5-9V3"/><path d="M7.5 15h9"/></svg><span>Lab</span>';
  b.addEventListener('click', () => { const a = window.__app; if (a && a.go) a.go('lab'); else L.open(); });
  if (anchor && anchor.parentNode) anchor.insertAdjacentElement('afterend', b);
  else bar.appendChild(b);
}
launcher();
new MutationObserver(launcher).observe(D.body, { childList: true, subtree: true });

/* shortcuts */
function shortcuts() {
  let m = $('#sc-help');
  if (m) { m.remove(); return; }
  m = D.createElement('div'); m.id = 'sc-help'; m.className = 'pro-modal';
  m.innerHTML = '<div class="pro-box"><button class="pro-x" aria-label="Close">x</button><h2>Keyboard shortcuts</h2>' +
    '<div class="labtbl"><table><tbody>' +
    [['Ctrl or Cmd + K', 'Search pages, levels, components and tools'], ['Alt + L', 'Open the Analysis Lab'], ['Alt + T', 'Open the finance toolkit'], ['Alt + I', 'Open cascade insights'], ['Ctrl + B', 'Collapse or expand the sidebar'], ['?', 'Show this help'], ['Esc', 'Close any panel']].map(r => '<tr><td><kbd>' + r[0] + '</kbd></td><td>' + r[1] + '</td></tr>').join('') +
    '</tbody></table></div><p class="labnote">Shortcuts work when the cursor is not inside a text field.</p></div>';
  D.body.appendChild(m); requestAnimationFrame(() => m.classList.add('on'));
  m.addEventListener('click', e => { if (e.target === m || e.target.closest('.pro-x')) m.remove(); });
}
D.addEventListener('keydown', e => {
  const t = e.target;
  if (t && /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)) return;
  if (e.altKey && !e.ctrlKey && !e.metaKey) {
    const k = e.key.toLowerCase();
    if (k === 'l') { e.preventDefault(); const a = window.__app; if (a && a.go) a.go('lab'); else L.open(); }
    else if (k === 't') { e.preventDefault(); const b = $('#tkb'); if (b) b.click(); }
    else if (k === 'i') { e.preventDefault(); const b = $('#insb'); if (b) b.click(); }
  }
  if (e.key === '?' && !e.ctrlKey && !e.metaKey) { e.preventDefault(); shortcuts(); }
});

/* make the palette reachable from the sidebar's existing search affordances */
const oldSearch = $('#searchbtn');
if (oldSearch) oldSearch.setAttribute('title', 'Search everything (Ctrl+K)');

/* tell the user once that the Lab is here */
try {
  if (!localStorage.getItem('sc-lab-seen')) {
    localStorage.setItem('sc-lab-seen', '1');
    setTimeout(() => { const b = $('#labbtn'); if (b) b.classList.add('pulse'); }, 1500);
  }
} catch (e) {}

console.log('Strategy Cascade Lab ready:', L.order.length, 'tools');
/* the page route may be in the URL before this bundle has defined vLab() */
if ((location.hash || '').replace(/^#/, '') === 'lab' && window.__app && window.__app.render) window.__app.render();
})();
