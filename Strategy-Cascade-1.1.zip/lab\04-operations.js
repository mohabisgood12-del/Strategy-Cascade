/* Strategy Cascade Lab - operations and supply tools */
(() => {
'use strict';
const L = window.__lab; if (!L) return;
const { E, N, num, pct, rows, tbl, kpi, bar, note, svg, ax, tx, clamp, col } = L;
const C = 'Operations and supply';

L.add(C, 'capacity', 'Capacity planning', 'Available capacity, the gap to demand, and the hours or people needed to close it.',
  [{ k: 'demand', l: 'Demand in units', d: '12000' }, { k: 'people', l: 'People available', d: '10' }, { k: 'hours', l: 'Productive hours per person per period', d: '140' }, { k: 'rate', l: 'Units per hour', d: '10' }, { k: 'util', l: 'Planned utilisation %', d: '85' }, { k: 'cost', l: 'Cost per extra hour', d: '35' }],
  v => {
    const demand = N(v.demand), people = N(v.people), hours = N(v.hours), rate = N(v.rate), util = N(v.util) / 100, cost = N(v.cost);
    const capacity = people * hours * rate * util, gap = demand - capacity, hoursNeed = rate > 0 ? gap / rate : 0, peopleNeed = hours > 0 ? hoursNeed / hours : 0;
    return kpi([['Capacity', num(capacity)], ['Demand', num(demand)], ['Gap', num(gap)], ['Extra hours', num(Math.max(0, hoursNeed))], ['Extra people', num(Math.max(0, peopleNeed), 1)], ['Extra cost', num(Math.max(0, hoursNeed) * cost)]]) +
      tbl(['Check', 'Value'], [['Utilisation', pct(util * 100)], ['Load', capacity ? pct(demand / capacity * 100) : 'n/a'], ['Status', gap > 0 ? '<b style="color:#c9473d">Short of capacity</b>' : '<b style="color:#2e9d62">Capacity covers demand</b>']]) +
      note('If the gap is more than 15% of capacity, adding people is usually cheaper and safer than overtime.');
  });

L.add(C, 'pce', 'Process cycle efficiency', 'The share of lead time that adds value, and how much waste to remove to hit a target.',
  [{ k: 'va', l: 'Value-added time (minutes)', d: '30' }, { k: 'lt', l: 'Total lead time (minutes)', d: '600' }, { k: 'target', l: 'Target efficiency %', d: '25' }],
  v => {
    const va = N(v.va), lt = N(v.lt), t = N(v.target) / 100;
    const pce = lt ? va / lt * 100 : 0, waste = Math.max(0, lt - va), ltNeed = t > 0 ? va / t : NaN;
    return kpi([['Cycle efficiency', pct(pce, 2)], ['Waste time', num(waste) + ' min'], ['Lead time to target', isFinite(ltNeed) ? num(ltNeed) + ' min' : 'n/a'], ['Waste to remove', isFinite(ltNeed) ? num(Math.max(0, lt - ltNeed)) + ' min' : 'n/a']]) +
      tbl(['Metric', 'Value'], [['Value-added share', pct(pce, 2)], ['Non-value-added share', pct(100 - pce, 2)], ['Lead time', num(lt) + ' min'], ['Verdict', pce >= 25 ? '<b style="color:#2e9d62">Efficient for a service process</b>' : '<b style="color:#d9922b">Most of the time is waiting</b>']]) +
      note('Most service processes run at 5-25% efficiency. The gain comes from removing waiting and handoffs, not from working faster.');
  });

L.add(C, 'eoq', 'Economic order quantity', 'The order size that minimises ordering plus holding cost, and the resulting cycle.',
  [{ k: 'd', l: 'Annual demand (units)', d: '24000' }, { k: 'o', l: 'Cost per order', d: '150' }, { k: 'h', l: 'Holding cost per unit per year', d: '8' }, { k: 'days', l: 'Working days per year', d: '250' }],
  v => {
    const d = N(v.d), o = N(v.o), h = N(v.h), days = Math.max(1, N(v.days));
    const eoq = h > 0 ? Math.sqrt(2 * d * o / h) : NaN, orders = eoq ? d / eoq : NaN, cycle = orders ? days / orders : NaN;
    const orderCost = orders ? orders * o : 0, holdCost = eoq ? eoq / 2 * h : 0;
    return kpi([['EOQ', isFinite(eoq) ? num(eoq) + ' units' : 'n/a'], ['Orders per year', isFinite(orders) ? num(orders, 1) : 'n/a'], ['Days between orders', isFinite(cycle) ? num(cycle, 1) : 'n/a'], ['Total annual cost', num(orderCost + holdCost)]]) +
      tbl(['Cost', 'Annual'], [['Ordering', num(orderCost)], ['Holding', num(holdCost)], ['<b>Total</b>', '<b>' + num(orderCost + holdCost) + '</b>']]) +
      note('At EOQ the ordering cost equals the holding cost. Round to the supplier pack size and re-check if demand changes by more than 20%.');
  });

L.add(C, 'supplier', 'Supplier scorecard', 'Weighted quality, delivery, cost and responsiveness with a grade and an action.',
  [{ k: 'v', l: 'One line per supplier: supplier|quality %|delivery %|cost score 1-5|responsiveness 1-5', d: 'Alpha|99|96|4|5\nBeta|94|88|3|3\nGamma|88|75|5|2', t: 't' }],
  v => {
    const r = rows(v.v).map(x => { const q = clamp(N(x[1]), 0, 100), d = clamp(N(x[2]), 0, 100), c = clamp(N(x[3]), 1, 5), s = clamp(N(x[4]), 1, 5); return { n: x[0] || 'Supplier', q, d, c, s, sc: q * 0.4 + d * 0.3 + c * 20 * 0.15 + s * 20 * 0.15 }; }).filter(x => x.n);
    if (!r.length) return note('Add at least one supplier: supplier|quality|delivery|cost|responsiveness.');
    r.sort((a, b) => b.sc - a.sc);
    const grade = s => s >= 90 ? ['A', '#2e9d62', 'Strategic partner'] : s >= 75 ? ['B', '#2e6bd9', 'Approved'] : s >= 60 ? ['C', '#d9922b', 'Improvement plan'] : ['D', '#c9473d', 'Replace or escalate'];
    return kpi([['Suppliers', r.length], ['Grade A', r.filter(x => x.sc >= 90).length], ['Average score', num(r.reduce((s, x) => s + x.sc, 0) / r.length, 1)], ['Best', E(r[0].n)]]) +
      tbl(['Supplier', 'Quality', 'Delivery', 'Cost', 'Responsive', 'Score', 'Grade', 'Action'], r.map(x => { const g = grade(x.sc); return [E(x.n), pct(x.q), pct(x.d), x.c, x.s, num(x.sc, 1), '<b style="color:' + g[1] + '">' + g[0] + '</b>', g[2]]; })) +
      note('Weights: quality 40%, delivery 30%, cost 15%, responsiveness 15%. A grade D supplier on a critical line needs a second source.');
  });

L.add(C, 'critpath', 'Critical path (CPM)', 'Forward and backward pass to find the critical path, total float and the project duration.',
  [{ k: 'v', l: 'One line per task: id|duration|depends on (comma separated ids)', d: 'A|3|\nB|5|A\nC|4|A\nD|2|B,C\nE|3|D', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ id: x[0] || '?', dur: Math.max(0, N(x[1])), dep: String(x[2] || '').split(',').map(s => s.trim()).filter(Boolean) })).filter(x => x.id);
    if (!r.length) return note('Add at least one task: id|duration|depends on.');
    const by = {}; r.forEach(x => by[x.id] = x);
    r.forEach(x => { x.es = 0; x.ef = x.dur; x.vis = 0; });
    let changed = true, guard = 0;
    while (changed && guard++ < 500) {
      changed = false;
      r.forEach(x => { const es = x.dep.reduce((s, d) => Math.max(s, by[d] ? by[d].ef : 0), 0); if (es !== x.es) { x.es = es; x.ef = es + x.dur; changed = true; } });
    }
    const end = r.reduce((s, x) => Math.max(s, x.ef), 0);
    r.forEach(x => { x.lf = end; x.ls = end - x.dur; });
    changed = true; guard = 0;
    while (changed && guard++ < 500) {
      changed = false;
      r.forEach(x => {
        const succ = r.filter(y => y.dep.includes(x.id));
        const lf = succ.length ? Math.min(...succ.map(y => y.ls)) : end;
        const ls = lf - x.dur;
        if (lf !== x.lf || ls !== x.ls) { x.lf = lf; x.ls = ls; changed = true; }
      });
    }
    r.forEach(x => x.slack = x.ls - x.es);
    const crit = r.filter(x => Math.abs(x.slack) < 0.001).map(x => x.id);
    return kpi([['Project duration', num(end) + ' days'], ['Tasks', r.length], ['Critical tasks', crit.length], ['Critical path', crit.join(' > ') || '-']]) +
      tbl(['Task', 'Duration', 'ES', 'EF', 'LS', 'LF', 'Float', 'Critical'], r.map(x => [E(x.id), num(x.dur), num(x.es), num(x.ef), num(x.ls), num(x.lf), num(x.slack), Math.abs(x.slack) < 0.001 ? '<b style="color:#c9473d">Yes</b>' : ''])) +
      note('Any delay on a critical task delays the project. Tasks with float can move without affecting the end date.');
  });

L.add(C, 'sla', 'Queue and service level (Erlang C)', 'Estimate wait time and service level for a queue with a given arrival rate and team size.',
  [{ k: 'arr', l: 'Contacts per hour', d: '120' }, { k: 'aht', l: 'Average handling time (minutes)', d: '6' }, { k: 'agents', l: 'Agents available', d: '14' }, { k: 'target', l: 'Target answer time (seconds)', d: '30' }],
  v => {
    const arr = Math.max(0, N(v.arr)), aht = Math.max(0.1, N(v.aht)), c = Math.max(1, Math.round(N(v.agents))), target = Math.max(1, N(v.target));
    const a = arr * aht / 60, rho = a / c;
    if (rho >= 1) return note('<b>The team is overloaded.</b> Offered load is ' + num(a, 2) + ' erlangs against ' + c + ' agents, so the queue grows without limit.');
    let b = 1; for (let i = 1; i <= c; i++) b = (a * b) / (i + a * b);
    const ec = b / (1 - rho * (1 - b));
    const wq = ec * aht / (c * (1 - rho)) * 60;
    const sl = 1 - ec * Math.exp(-(c - a) * (target / 60) / aht);
    return kpi([['Utilisation', pct(rho * 100)], ['Probability of waiting', pct(ec * 100)], ['Average wait', num(wq, 1) + ' sec'], ['Service level in ' + target + ' sec', pct(sl * 100)]]) +
      tbl(['Check', 'Value'], [['Offered load', num(a, 2) + ' erlangs'], ['Agents', c], ['Average speed of answer', num(wq, 1) + ' sec'], ['Status', sl >= 0.8 ? '<b style="color:#2e9d62">Meets an 80/30 target</b>' : '<b style="color:#d9922b">Below an 80/30 target</b>']]) +
      note('Erlang C assumes random arrivals and no abandonments. Above 85% utilisation, wait times rise steeply for every extra point of load.');
  });

L.add(C, 'copq', 'Cost of poor quality', 'Total failure and appraisal cost, its share of revenue, and the Pareto of causes.',
  [{ k: 'rev', l: 'Revenue', d: '10000000' }, { k: 'v', l: 'One line per category: category|annual cost', d: 'Rework|180000\nWarranty|120000\nScrap|60000\nComplaints|40000\nInspection|90000', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Category', c: N(x[1]) })).filter(x => x.c);
    if (!r.length) return note('Add at least one cost category: category|annual cost.');
    r.sort((a, b) => b.c - a.c);
    const total = r.reduce((s, x) => s + x.c, 0), rev = N(v.rev), max = r[0].c;
    let cum = 0;
    return kpi([['Total cost', num(total)], ['Share of revenue', rev ? pct(total / rev * 100, 2) : 'n/a'], ['Largest cause', E(r[0].n)], ['Causes', r.length]]) +
      tbl(['Category', 'Cost', 'Share', 'Cumulative', ''], r.map(x => { cum += x.c; return [E(x.n), num(x.c), pct(x.c / total * 100), pct(cum / total * 100), bar(x.c / max * 100, '#c9473d')]; })) +
      note('Fix the first two categories first: they usually carry most of the cost. Inspection is a prevention cost, not a failure cost.');
  });

L.add(C, 'invturn', 'Inventory turns and days', 'Turns, days of inventory and the cash released by hitting a turns target.',
  [{ k: 'cogs', l: 'Annual cost of goods sold', d: '6000000' }, { k: 'inv', l: 'Average inventory value', d: '750000' }, { k: 'target', l: 'Target turns per year', d: '10' }],
  v => {
    const cogs = N(v.cogs), inv = Math.max(1, N(v.inv)), target = Math.max(0.1, N(v.target));
    const turns = cogs / inv, dio = turns ? 365 / turns : NaN, invTarget = cogs / target, release = inv - invTarget;
    return kpi([['Turns per year', num(turns, 2)], ['Days of inventory', num(dio, 1)], ['Target inventory', num(invTarget)], ['Cash released', num(release)]]) +
      tbl(['Metric', 'Value'], [['Inventory value', num(inv)], ['Cost of goods sold', num(cogs)], ['Turns', num(turns, 2)], ['Days', num(dio, 1)], ['Verdict', turns >= target ? '<b style="color:#2e9d62">At or above target</b>' : '<b style="color:#d9922b">Below target</b>']]) +
      note('Raising turns from ' + num(turns, 1) + ' to ' + num(target, 1) + ' would free ' + num(Math.max(0, release)) + ' of cash, before any write-downs.');
  });
})();
