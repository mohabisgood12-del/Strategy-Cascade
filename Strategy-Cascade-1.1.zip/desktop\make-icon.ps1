Add-Type -AssemblyName System.Drawing

$out = Join-Path $PSScriptRoot 'app.ico'
$pngTmp = Join-Path $env:TEMP 'sc-icon-256.png'
$size = 256
$bmp = New-Object System.Drawing.Bitmap($size, $size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.Clear([System.Drawing.Color]::Transparent)

$bg = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, 15, 18, 24))
$path = New-Object System.Drawing.Drawing2D.GraphicsPath
$r = 56
$path.AddArc(4, 4, $r, $r, 180, 90)
$path.AddArc($size - 4 - $r, 4, $r, $r, 270, 90)
$path.AddArc($size - 4 - $r, $size - 4 - $r, $r, $r, 0, 90)
$path.AddArc(4, $size - 4 - $r, $r, $r, 90, 90)
$path.CloseFigure()
$g.FillPath($bg, $path)
$pen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(255, 44, 50, 62), 5)
$g.DrawPath($pen, $path)

function Bar($x, $y, $w, $h, $col) {
  $b = New-Object System.Drawing.SolidBrush($col)
  $p = New-Object System.Drawing.Drawing2D.GraphicsPath
  $p.AddArc($x, $y, $h, $h, 90, 180)
  $p.AddArc($x + $w - $h, $y, $h, $h, 270, 180)
  $p.CloseFigure()
  $g.FillPath($b, $p)
  $b.Dispose(); $p.Dispose()
}

Bar 52 72 152 26 ([System.Drawing.Color]::FromArgb(255, 122, 168, 232))
Bar 52 112 112 26 ([System.Drawing.Color]::FromArgb(255, 66, 132, 216))
Bar 52 152 76 26 ([System.Drawing.Color]::FromArgb(255, 226, 156, 58))

$g.Dispose()
$bmp.Save($pngTmp, [System.Drawing.Imaging.ImageFormat]::Png)

# single-entry ICO that carries the 256x256 PNG (Vista and later)
$png = [System.IO.File]::ReadAllBytes($pngTmp)
$ms = New-Object System.IO.MemoryStream
$bw = New-Object System.IO.BinaryWriter($ms)
$bw.Write([UInt16]0)          # reserved
$bw.Write([UInt16]1)          # type: icon
$bw.Write([UInt16]1)          # one image
$bw.Write([Byte]0)            # width 0 = 256
$bw.Write([Byte]0)            # height 0 = 256
$bw.Write([Byte]0)            # palette
$bw.Write([Byte]0)            # reserved
$bw.Write([UInt16]1)          # planes
$bw.Write([UInt16]32)         # bits per pixel
$bw.Write([UInt32]$png.Length)
$bw.Write([UInt32]22)         # offset
$bw.Write($png)
$bw.Flush()
[System.IO.File]::WriteAllBytes($out, $ms.ToArray())
$bw.Dispose(); $ms.Dispose(); $bmp.Dispose()

Write-Output "icon: $out ($((Get-Item $out).Length) bytes)"
