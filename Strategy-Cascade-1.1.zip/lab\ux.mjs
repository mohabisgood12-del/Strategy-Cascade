import { spawn } from 'node:child_process';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const FILE = 'file:///C:/Users/LENOVO/Documents/Default%20Project/Strategy-Cascade-main/index.html';
const PORT = 9335;
const profile = mkdtempSync(join(tmpdir(), 'sc-ux-'));
const chrome = spawn(CHROME, ['--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check', '--allow-file-access-from-files', `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, 'about:blank'], { stdio: 'ignore' });
const sleep = ms => new Promise(r => setTimeout(r, ms));
let v;
for (let i = 0; i < 40; i++) { try { const r = await fetch(`http://127.0.0.1:${PORT}/json/version`); if (r.ok) { v = await r.json(); break; } } catch (e) {} await sleep(250); }
const ws = new WebSocket(v.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
let id = 0; const pending = new Map(); const events = [];
ws.onmessage = e => { const m = JSON.parse(e.data); if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); } else if (m.method) events.push(m); };
const send = (method, params = {}, sessionId) => { const mid = ++id; ws.send(JSON.stringify({ id: mid, method, params, ...(sessionId ? { sessionId } : {}) })); return new Promise(res => pending.set(mid, res)); };
const t = await send('Target.createTarget', { url: 'about:blank' });
const a = await send('Target.attachToTarget', { targetId: t.result.targetId, flatten: true });
const sid = a.result.sessionId;
await send('Runtime.enable', {}, sid);
await send('Log.enable', {}, sid);
await send('Page.enable', {}, sid);
await send('Page.navigate', { url: FILE }, sid);
await sleep(3000);
async function ev(expression) {
  const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true }, sid);
  if (r.result && r.result.exceptionDetails) return { ERROR: (r.result.exceptionDetails.exception && r.result.exceptionDetails.exception.description) || r.result.exceptionDetails.text };
  return r.result && r.result.result ? r.result.result.value : 'NO-VALUE';
}
for (let i = 0; i < 20; i++) { if (await ev('typeof window.__lab') === 'object') break; await sleep(250); }
await ev('1+1');

const out = {};

// seed a plan so every prefill and write-back has data
out.seed = await ev(`(()=>{
  const a=window.__app;
  a.ALLC.slice(0,6).forEach((c,i)=>{ const d=a.getC(c.id);
    d.owner=['Ana Silva','Ben Okafor','Chen Wu','Dara Patel','Eli Berg','Fiona Rossi'][i];
    d.due='2026-1'+(i+1)+'-15'; d.st=[1,2,4,3,0,1][i];
    d.rk='Risk number '+i+' with a long enough description';
    d.dec='Decision '+i+' approved';
    d.kp.push({k:'Metric '+i,b:'10',t:'20',h:'+10'});
  });
  return {seeded:6};
})()`);

// 1. output quality: no NaN / undefined / Infinity in any default render
out.quality = await ev(`(()=>{
  const L=window.__lab, bad=[];
  for (const id of L.order) {
    const t=L.T[id], v={};
    t.f.forEach(f=>{ v[f.k]= f.t==='c' ? !!f.d : (f.d==null?'':f.d); });
    let h=''; try { h=String(t.r(v)||''); } catch(e){ bad.push([id,'THROW '+e.message]); continue; }
    const txt=h.replace(/<[^>]*>/g,' ');
    ['NaN','undefined','Infinity','[object'].forEach(w=>{ if(txt.includes(w)) bad.push([id,w]); });
  }
  return bad;
})()`);

// 1b. stress: zero every numeric input, blank text, first option of every select
out.qualityZero = await ev(`(()=>{
  const L=window.__lab, bad=[];
  for (const id of L.order) {
    const t=L.T[id], v={};
    t.f.forEach(f=>{ v[f.k]= f.t==='c' ? false : f.t==='t' ? 'A|0|0|0\\nB|0|0|0' : f.t==='s' ? ((f.o&&f.o[0])||'') : '0'; });
    let h=''; try { h=String(t.r(v)||''); } catch(e){ bad.push([id,'THROW '+e.message]); continue; }
    const txt=h.replace(/<[^>]*>/g,' ');
    ['NaN','undefined','Infinity','[object'].forEach(w=>{ if(txt.includes(w)) bad.push([id,w]); });
  }
  return bad;
})()`);

// 1c. stress: large values
out.qualityBig = await ev(`(()=>{
  const L=window.__lab, bad=[];
  for (const id of L.order) {
    const t=L.T[id], v={};
    t.f.forEach(f=>{ v[f.k]= f.t==='c' ? true : f.t==='t' ? 'A|999999|888888|777777\\nB|555555|444444|333333' : f.t==='s' ? ((f.o&&f.o[0])||'') : '999999'; });
    let h=''; try { h=String(t.r(v)||''); } catch(e){ bad.push([id,'THROW '+e.message]); continue; }
    const txt=h.replace(/<[^>]*>/g,' ');
    ['NaN','undefined','Infinity','[object'].forEach(w=>{ if(txt.includes(w)) bad.push([id,w]); });
  }
  return bad;
})()`);

// 2. every tool renders into the modal with no exception, and keeps its inputs on re-render
out.renderAll = await ev(`(()=>{
  const L=window.__lab, bad=[], empty=[];
  for (const id of L.order) {
    try {
      L.open(id);
      const main=document.querySelector('#labmain');
      const out=document.querySelector('#labout');
      if(!main || !out) { bad.push([id,'missing DOM']); continue; }
      if((out.textContent||'').trim().length < 8) empty.push(id);
    } catch(e){ bad.push([id,e.message]); }
  }
  const m=document.querySelector('#labm'); if(m) m.remove();
  return {bad, empty};
})()`);

// 3. search filter
out.search = await ev(`(()=>{
  const L=window.__lab; L.open();
  const q=document.querySelector('#labq');
  q.value='break-even'; q.dispatchEvent(new Event('input',{bubbles:true}));
  const items=[...document.querySelectorAll('#labnav [data-tool]')].map(b=>b.dataset.tool);
  q.value='zzzznothing'; q.dispatchEvent(new Event('input',{bubbles:true}));
  const none=document.querySelector('#labnav').textContent.includes('No tool matches');
  q.value=''; q.dispatchEvent(new Event('input',{bubbles:true}));
  const all=[...document.querySelectorAll('#labnav [data-tool]')].length;
  return {filtered:items, noMatchShown:none, restored:all};
})()`);

// 4. favourites persist and show in the nav
out.favourites = await ev(`(()=>{
  const L=window.__lab; L.open('dcf');
  document.querySelector('#labfav').click();
  const stored=JSON.parse(localStorage.getItem('sc-lab-favs')||'[]');
  const navHas=!!document.querySelector('#labnav [data-tool="dcf"]');
  L.open('wacc');
  document.querySelector('#labfav').click();
  const after=JSON.parse(localStorage.getItem('sc-lab-favs')||'[]');
  return {stored, navHas, after};
})()`);

// 5. CSV export, copy, print, reset
out.actions = await ev(`(()=>{
  const L=window.__lab, res={};
  let dl=null;
  const orig=HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click=function(){ dl={name:this.download, href:this.href}; };
  L.open('be');
  const csv=[...document.querySelectorAll('#labmain [data-lab]')].find(b=>b.dataset.lab==='csv');
  csv.click();
  HTMLAnchorElement.prototype.click=orig;
  res.csv={name:dl&&dl.name, blob:!!(dl&&String(dl.href).startsWith('blob:'))};
  const inp=document.querySelector('#labmain [data-f="price"]');
  inp.value='250'; inp.dispatchEvent(new Event('input',{bubbles:true}));
  const changed=document.querySelector('#labout').textContent.includes('210.00');
  const reset=[...document.querySelectorAll('#labmain [data-lab]')].find(b=>b.dataset.lab==='reset');
  reset.click();
  const back=document.querySelector('#labmain [data-f="price"]').value;
  res.reset={changed, back};
  const pr=[...document.querySelectorAll('#labmain [data-lab]')].find(b=>b.dataset.lab==='print');
  res.printButton=!!pr;
  const cp=[...document.querySelectorAll('#labmain [data-lab]')].find(b=>b.dataset.lab==='copy');
  cp.click();
  res.copy={clicked:true};
  return res;
})()`);

// 6. write-back for the remaining tools
out.pushAll = await ev(`(()=>{
  const L=window.__lab, a=window.__app, res={};
  const target=a.ALLC[2].id;
  const run=(toolId,field)=>{
    L.open(toolId);
    const sel=document.querySelector('#labpush'); if(sel) sel.value=target;
    const d=a.getC(target);
    const snap=JSON.stringify({rk:d.rk,kp:d.kp,dec:d.dec,due:d.due,owner:d.owner});
    const btn=[...document.querySelectorAll('#labmain [data-lab]')].find(b=>b.dataset.lab==='push');
    if(!btn) return {error:'no push'};
    btn.click();
    const d2=a.getC(target);
    const now=JSON.stringify({rk:d2.rk,kp:d2.kp,dec:d2.dec,due:d2.due,owner:d2.owner});
    return {changed:snap!==now, stored: JSON.parse(localStorage.getItem('strategy-cascade-v1')||'{}').c[target] ? true : false};
  };
  res.premortem=run('premortem');
  res.vendorrisk=run('vendorrisk');
  res.decisionlog=run('decisionlog');
  res.benefits=run('benefits');
  res.okralign=run('okralign');
  res.riskreg=run('riskreg');
  const m=document.querySelector('#labm'); if(m) m.remove();
  return res;
})()`);

// 7. plan90 writes due dates across the plan
out.plan90 = await ev(`(()=>{
  const L=window.__lab, a=window.__app;
  const before=a.ALLC.map(c=>a.getC(c.id).due).join('|');
  L.open('plan90');
  const res={};
  res.title=(document.querySelector('.labtitle h3')||{}).textContent||null;
  const btn=[...document.querySelectorAll('#labmain [data-lab]')].find(b=>b.dataset.lab==='push');
  res.pushBtn=!!btn;
  res.scopeSel=document.querySelector('#labmain [data-f="scope"]') ? document.querySelector('#labmain [data-f="scope"]').value : null;
  btn.click();
  const after=a.ALLC.map(c=>a.getC(c.id).due).join('|');
  const owners=new Set(a.ALLC.map(c=>a.getC(c.id).owner).filter(Boolean));
  res.toast=document.querySelector('#toast').textContent;
  res.changed=before!==after;
  res.owners=owners.size;
  const m=document.querySelector('#labm'); if(m) m.remove();
  return res;
})()`);

// 8. palette: keyboard open, arrow keys, escape close
out.paletteKeys = await ev(`(async()=>{
  const res={};
  res.hasPalette=typeof (window.__lab||{}).palette;
  res.cpPresent=!!document.querySelector('#cp');
  res.cpClassBefore=document.querySelector('#cp')?document.querySelector('#cp').className:'none';
  const key=(k,opts={})=>document.dispatchEvent(new KeyboardEvent('keydown',Object.assign({key:k,bubbles:true,cancelable:true},opts)));
  try { window.__lab.palette(); res.directOpen=document.querySelector('#cp').classList.contains('on'); } catch(e){ res.directOpen='ERR '+e.message; }
  try { document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true,cancelable:true})); } catch(e){}
  key('k',{ctrlKey:true});
  res.opened=document.querySelector('#cp').classList.contains('on');
  res.items=document.querySelectorAll('#cpl a').length;
  res.onItems=document.querySelectorAll('#cpl a.on').length;
  const el=document.querySelector('#cpl a.on span');
  res.first=el?el.textContent:null;
  res.cplStart=(document.querySelector('#cpl')||{innerHTML:''}).innerHTML.slice(0,120);
  if(!el) return res;
  key('ArrowDown');
  const on2=document.querySelector('#cpl a.on');
  res.moved=!!on2 && on2.dataset.i==='1';
  const inp=document.querySelector('#cpi'); inp.value='lab tool'; inp.dispatchEvent(new Event('input',{bubbles:true}));
  res.filtered=document.querySelectorAll('#cpl a').length;
  key('Escape');
  res.closed=!document.querySelector('#cp').classList.contains('on');
  return res;
})()`);

// 9. Alt+L and ? shortcuts
out.shortcuts = await ev(`(()=>{
  const res={};
  const key=(k,opts={})=>document.dispatchEvent(new KeyboardEvent('keydown',Object.assign({key:k,bubbles:true,cancelable:true},opts)));
  key('l',{altKey:true});
  res.labRoute=location.hash;
  res.labPage=!!document.querySelector('#labpagegrid');
  key('?');
  res.helpOpened=!!document.querySelector('#sc-help');
  const rows=document.querySelectorAll('#sc-help tr').length;
  key('Escape');
  const m=document.querySelector('#sc-help'); if(m) m.remove();
  res.helpRows=rows;
  window.__app.go('home');
  return res;
})()`);

// 9b. the native Analysis Lab page: cards, search, category filter, open a tool
out.labPage = await ev(`(()=>{
  window.__app.go('lab');
  const res={route:location.hash};
  res.nav=!!document.querySelector('#navlist [data-go="lab"]');
  res.active=!!document.querySelector('#navlist [data-go="lab"].on');
  res.head=(document.querySelector('#main h1')||{}).textContent||'';
  res.cards=document.querySelectorAll('#labpagegrid [data-labopen]').length;
  res.chips=document.querySelectorAll('[data-labcat]').length;
  const q=document.querySelector('#labpageq');
  q.value='break-even'; q.dispatchEvent(new Event('input',{bubbles:true}));
  res.filtered=document.querySelectorAll('#labpagegrid [data-labopen]').length;
  q.value=''; q.dispatchEvent(new Event('input',{bubbles:true}));
  const chip=[...document.querySelectorAll('[data-labcat]')].find(b=>b.dataset.labcat==='Risk and governance');
  chip.click();
  res.catFiltered=document.querySelectorAll('#labpagegrid [data-labopen]').length;
  res.catOn=chip.classList.contains('on');
  [...document.querySelectorAll('[data-labcat]')][0].click();
  const card=document.querySelector('#labpagegrid [data-labopen="dcf"]');
  card.click();
  res.modalOpened=!!document.querySelector('#labm');
  res.modalTitle=(document.querySelector('.labtitle h3')||{}).textContent||'';
  const m=document.querySelector('#labm'); if(m) m.remove();
  window.__app.go('home');
  return res;
})()`);

// 10. launcher button exists once and opens the Lab page
out.launcher = await ev(`(()=>{
  const b=document.querySelector('#labbtn');
  if(!b) return {error:'no button'};
  b.click();
  const open=location.hash==='#lab' && !!document.querySelector('#labpagegrid');
  window.__app.go('home');
  return {count:document.querySelectorAll('#labbtn').length, open};
})()`);

// 11. the original app still works: routes, stats and the existing top-bar panels
out.coreApp = await ev(`(()=>{
  const a=window.__app, r={};
  r.levels=a.LV.length; r.components=a.ALLC.length;
  r.stats=typeof a.wsStats(a.LV)==='object';
  a.go('home'); r.homeRoute=a.route.v;
  a.go('domains'); r.domRoute=a.route.v;
  a.go('outputs'); r.outRoute=a.route.v;
  a.go('home');
  r.mainHasContent=(document.querySelector('#main')||{textContent:''}).textContent.length>50;
  r.navHasContent=(document.querySelector('#navmain')||{textContent:''}).textContent.length>20;
  return r;
})()`);
out.existingButtons = await ev(`(()=>{
  const res={};
  ['tkb','insb','askc'].forEach(id=>{
    const b=document.getElementById(id);
    if(!b){res[id]='missing';return;}
    const before=document.body.children.length;
    try{ b.click(); res[id]={grew:document.body.children.length>before}; }catch(e){ res[id]='ERR '+e.message; }
  });
  document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true,cancelable:true}));
  document.querySelectorAll('.pro-modal').forEach(m=>m.remove());
  return res;
})()`);

// print last: it spawns a print iframe that can steal focus in headless runs
out.print = await ev(`(()=>{
  const L=window.__lab;
  L.open('be');
  const before=document.querySelectorAll('iframe').length;
  const pr=[...document.querySelectorAll('#labmain [data-lab]')].find(b=>b.dataset.lab==='print');
  pr.click();
  const during=document.querySelectorAll('iframe').length;
  const m=document.querySelector('#labm'); if(m) m.remove();
  return {before, during, spawned:during>before};
})()`);

out.errors = events.filter(e => e.method === 'Runtime.exceptionThrown').map(e => JSON.stringify(e.params).slice(0, 400));
out.consoleErrors = events.filter(e => e.method === 'Runtime.consoleAPICalled' && e.params.type === 'error').map(e => (e.params.args || []).map(x => x.value || x.description).join(' ').slice(0, 300));
console.log(JSON.stringify(out, null, 2));
ws.close(); chrome.kill(); process.exit(0);
