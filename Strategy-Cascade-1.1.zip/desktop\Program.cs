using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

[assembly: AssemblyTitle("Strategy Cascade")]
[assembly: AssemblyProduct("Strategy Cascade")]
[assembly: AssemblyDescription("Strategy Cascade desktop app")]
[assembly: AssemblyCompany("Strategy Cascade")]
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]

namespace StrategyCascade
{
    static class Program
    {
        const string ResName = "index.html";

        [STAThread]
        static int Main(string[] args)
        {
            bool selftest = Array.IndexOf(args, "--selftest") >= 0;
            string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Strategy Cascade");
            string html = Path.Combine(dir, "index.html");

            try
            {
                Directory.CreateDirectory(dir);
                Extract(html);
            }
            catch (Exception ex)
            {
                if (selftest) { Console.Error.WriteLine("extract failed: " + ex.Message); return 2; }
                MessageBox.Show("The app files could not be unpacked.\n\n" + ex.Message, "Strategy Cascade", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 2;
            }

            if (selftest)
            {
                Console.WriteLine("html=" + html);
                Console.WriteLine("bytes=" + new FileInfo(html).Length);
                string b0 = FindBrowser();
                Console.WriteLine("browser=" + (b0 == null ? "none" : b0));
                return 0;
            }

            string profile = Path.Combine(dir, "profile");
            string browser = FindBrowser();
            if (browser != null)
            {
                try
                {
                    ProcessStartInfo psi = new ProcessStartInfo(browser);
                    psi.UseShellExecute = false;
                    psi.Arguments = "--app=\"" + new Uri(html).AbsoluteUri + "\"" +
                                    " --user-data-dir=\"" + profile + "\"" +
                                    " --window-size=1440,940" +
                                    " --no-first-run --no-default-browser-check";
                    Process.Start(psi);
                    return 0;
                }
                catch { }
            }

            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(html);
                psi.UseShellExecute = true;
                Process.Start(psi);
                return 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not open the app.\n\n" + ex.Message + "\n\nThe page is at:\n" + html,
                                "Strategy Cascade", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
        }

        static void Extract(string target)
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            using (Stream s = asm.GetManifestResourceStream(ResName))
            {
                if (s == null)
                {
                    string sibling = Path.Combine(Path.GetDirectoryName(asm.Location), "index.html");
                    if (File.Exists(sibling)) { File.Copy(sibling, target, true); return; }
                    throw new InvalidOperationException("embedded index.html is missing");
                }
                using (FileStream fs = new FileStream(target, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    s.CopyTo(fs);
                }
            }
        }

        static string FindBrowser()
        {
            string pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            string pf86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string[] paths = new string[]
            {
                Path.Combine(pf86, @"Microsoft\Edge\Application\msedge.exe"),
                Path.Combine(pf, @"Microsoft\Edge\Application\msedge.exe"),
                Path.Combine(pf, @"Google\Chrome\Application\chrome.exe"),
                Path.Combine(pf86, @"Google\Chrome\Application\chrome.exe"),
                Path.Combine(local, @"Google\Chrome\Application\chrome.exe")
            };
            foreach (string p in paths) if (File.Exists(p)) return p;
            return null;
        }
    }
}
