import { spawn } from 'node:child_process';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const FILE = 'file:///C:/Users/LENOVO/Documents/Default%20Project/Strategy-Cascade-main/index.html';
const PORT = 9333;
const profile = mkdtempSync(join(tmpdir(), 'sc-smoke-'));

const chrome = spawn(CHROME, [
  '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
  '--allow-file-access-from-files', `--remote-debugging-port=${PORT}`,
  `--user-data-dir=${profile}`, 'about:blank'
], { stdio: 'ignore' });

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function version() {
  for (let i = 0; i < 40; i++) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/version`);
      if (r.ok) return await r.json();
    } catch (e) {}
    await sleep(250);
  }
  throw new Error('Chrome did not start');
}

const v = await version();
const ws = new WebSocket(v.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });

let id = 0;
const pending = new Map();
const events = [];
ws.onmessage = ev => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); }
  else if (m.method) events.push(m);
};
function send(method, params = {}, sessionId) {
  const mid = ++id;
  ws.send(JSON.stringify({ id: mid, method, params, ...(sessionId ? { sessionId } : {}) }));
  return new Promise(res => pending.set(mid, res));
}

const target = await send('Target.createTarget', { url: 'about:blank' });
const attach = await send('Target.attachToTarget', { targetId: target.result.targetId, flatten: true });
const sid = attach.result.sessionId;
await send('Runtime.enable', {}, sid);
await send('Log.enable', {}, sid);
await send('Page.enable', {}, sid);
await send('Page.navigate', { url: FILE }, sid);
await sleep(3500);

async function ev(expression) {
  const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true }, sid);
  if (r.result && r.result.exceptionDetails) return { error: r.result.exceptionDetails.text, desc: r.result.exceptionDetails.exception && r.result.exceptionDetails.exception.description };
  return r.result && r.result.result ? r.result.result.value : undefined;
}

// warm-up: the first evaluate after navigation can land in the stale context
for (let i = 0; i < 20; i++) {
  if (await ev('typeof window.__lab') === 'object') break;
  await sleep(250);
}
await ev('1+1');

const out = {};
out.paletteHiddenInitially = await ev('getComputedStyle(document.querySelector("#cp")).display');
out.tools = await ev('window.__lab ? window.__lab.order.length : -1');
out.appApi = await ev('window.__app && typeof window.__app.setField === "function" && typeof window.__app.render === "function"');
out.paletteItems = await ev('(()=>{window.__lab.palette();const n=document.querySelectorAll("#cpl a").length;return n})()');
out.paletteVisible = await ev('getComputedStyle(document.querySelector("#cp")).display');
out.runAll = await ev(`(()=>{
  const L=window.__lab, bad=[], empty=[];
  for (const id of L.order) {
    const t=L.T[id]; const v={};
    t.f.forEach(f=>{ v[f.k] = f.t==='c' ? !!f.d : (f.d==null?'':f.d); });
    try { const h=t.r(v); if(!h || String(h).length<8) empty.push(id); }
    catch(e){ bad.push([id,e.message]); }
  }
  return {bad, empty};
})()`);
out.prefill = await ev(`(()=>{
  const L=window.__lab, bad=[], ok=[];
  for (const id of L.order) { const t=L.T[id]; if(!t.pre) continue;
    try { const p=t.pre(); if(p) ok.push(id); } catch(e){ bad.push([id,e.message]); } }
  return {ok, bad};
})()`);
out.openTool = await ev(`(()=>{ window.__lab.open('be'); const t=document.querySelector('#labout')?document.querySelector('#labout').innerText:''; return {fields:document.querySelectorAll('#labmain [data-f]').length, text:t.slice(0,160)}; })()`);
out.mutate = await ev(`(()=>{ const a=window.__app; const c=a.ALLC[0]; const before=a.getC(c.id).owner; a.setField(c.id,'owner','Smoke Test Owner'); const after=a.getC(c.id).owner; return {before, after, stored: JSON.parse(localStorage.getItem('strategy-cascade-v1')||'{}').c[c.id].owner}; })()`);

// populate the plan, then exercise prefill and both write-back paths
out.seed = await ev(`(()=>{
  const a=window.__app;
  const c1=a.ALLC[0], c2=a.ALLC[1];
  a.setField(c1.id,'owner','Ana Silva');
  a.setField(c1.id,'due','2026-12-01');
  a.setField(c1.id,'rk','Supplier concentration risk\\nKey person dependency');
  a.setField(c1.id,'st',4);
  a.setField(c2.id,'owner','Ben Okafor');
  a.setField(c2.id,'due','2027-01-15');
  a.setField(c2.id,'st',1);
  a.addKpi(c1.id,{k:'Gross margin',b:'32',t:'40',h:'+8 pts'});
  a.addKpi(c2.id,{k:'Win rate',b:'21',t:'30',h:'+9 pts'});
  return {c1:c1.id, c2:c2.id};
})()`);
out.prefillPopulated = await ev(`(()=>{
  const L=window.__lab, ok=[], empty=[], bad=[];
  for (const id of L.order) { const t=L.T[id]; if(!t.pre) continue;
    try { const p=t.pre(); (p && Object.keys(p).length ? ok : empty).push(id); } catch(e){ bad.push([id,e.message]); }
  }
  return {ok, empty, bad};
})()`);
out.pushRisk = await ev(`(()=>{
  const L=window.__lab, a=window.__app, id=a.ALLC[0].id;
  const before=String(a.getC(id).rk||'');
  L.open('riskreg');
  const sel=document.querySelector('#labpush'); if(sel) sel.value=id;
  const btn=[...document.querySelectorAll('#labmain [data-lab]')].find(b=>b.dataset.lab==='push');
  if(!btn) return {error:'no push button'};
  btn.click();
  const after=String(a.getC(id).rk||'');
  return {beforeLen:before.length, afterLen:after.length, grew:after.length>before.length,
    stored: String((JSON.parse(localStorage.getItem('strategy-cascade-v1')||'{}').c[id]||{}).rk||'').length};
})()`);
out.pushKpi = await ev(`(()=>{
  const L=window.__lab, a=window.__app, id=a.ALLC[1].id;
  const before=a.getC(id).kp.length;
  L.open('okralign');
  const sel=document.querySelector('#labpush'); if(sel) sel.value=id;
  const pre=[...document.querySelectorAll('#labmain [data-lab]')].find(b=>b.dataset.lab==='pre');
  if(pre) pre.click();
  const msg=document.querySelector('#labprem') ? document.querySelector('#labprem').textContent : '';
  const sel2=document.querySelector('#labpush'); if(sel2) sel2.value=id;
  const btn=[...document.querySelectorAll('#labmain [data-lab]')].find(b=>b.dataset.lab==='push');
  if(!btn) return {error:'no push button'};
  btn.click();
  const after=a.getC(id).kp.length;
  return {before, after, grew: after>before, msg, stored: JSON.parse(localStorage.getItem('strategy-cascade-v1')||'{}').c[id].kp.length};
})()`);
out.errors = events.filter(e => e.method === 'Runtime.exceptionThrown' || (e.method === 'Log.entryAdded' && e.params.entry.level === 'error')).map(e => JSON.stringify(e.params).slice(0, 400));
out.consoleErrors = events.filter(e => e.method === 'Runtime.consoleAPICalled' && e.params.type === 'error').map(e => (e.params.args||[]).map(a => a.value || a.description).join(' ').slice(0, 300));

console.log(JSON.stringify(out, null, 2));
ws.close();
chrome.kill();
process.exit(0);
