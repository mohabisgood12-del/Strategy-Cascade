/* Strategy Cascade Lab - risk and governance tools */
(() => {
'use strict';
const L = window.__lab; if (!L) return;
const { E, N, num, pct, rows, tbl, kpi, bar, note, svg, ax, tx, clamp, col } = L;
const C = 'Risk and governance';
const band = s => s >= 20 ? ['Critical', '#c9473d'] : s >= 12 ? ['High', '#d9922b'] : s >= 6 ? ['Medium', '#c9a227'] : ['Low', '#2e9d62'];

L.add(C, 'riskreg', 'Risk register scoring', 'Score inherent risk, apply control effectiveness and rank the residual risk.',
  [{ k: 'v', l: 'One line per risk: risk|likelihood 1-5|impact 1-5|control effectiveness %|owner', d: 'Supplier failure|4|5|40|Ops\nCyber breach|3|5|60|IT\nKey person loss|3|4|25|HR', t: 't', r: 5 }],
  v => {
    const r = rows(v.v).map(x => { const l = clamp(N(x[1]), 1, 5), i = clamp(N(x[2]), 1, 5), c = clamp(N(x[3]), 0, 100); return { n: x[0] || 'Risk', l, i, c, own: x[4] || '', inh: l * i, res: l * i * (1 - c / 100) }; }).filter(x => x.n);
    if (!r.length) return note('Add at least one risk: risk|likelihood|impact|control effectiveness|owner.');
    r.sort((a, b) => b.res - a.res);
    const crit = r.filter(x => x.res >= 12).length;
    return kpi([['Risks', r.length], ['Residual above 12', crit], ['Highest residual', num(r[0].res, 1)], ['Average reduction', pct(r.reduce((s, x) => s + (1 - x.res / (x.inh || 1)), 0) / r.length * 100)]]) +
      tbl(['Risk', 'L', 'I', 'Inherent', 'Control', 'Residual', 'Rating', 'Owner'], r.map(x => { const b = band(x.res); return [E(x.n), x.l, x.i, num(x.inh), pct(x.c), num(x.res, 1), '<b style="color:' + b[1] + '">' + b[0] + '</b>', E(x.own)]; })) +
      note('Residual score = likelihood x impact x (1 - control effectiveness). Anything above 12 needs a named owner and a dated action.');
  }, {
  pre: () => { const a = window.__app; if (!a) return null; const out = []; a.ALLC.forEach(c => { const d = a.getC(c.id); if (String(d.rk || '').trim()) String(d.rk).split(/[;\n]+/).map(x => x.trim()).filter(x => x.length > 6).forEach(x => out.push(x + '|3|4|0|' + (d.owner || ''))); }); return out.length ? { v: out.slice(0, 20).join('\n') } : null; },
  push: v => { const list = rows(v.v).map(x => (x[0] || '') + ' (residual ' + (clamp(N(x[1]), 1, 5) * clamp(N(x[2]), 1, 5) * (1 - clamp(N(x[3]), 0, 100) / 100)).toFixed(1) + ')').filter(x => x.length > 4); return L.pushRisks(list); }
});

L.add(C, 'mcpert', 'Monte Carlo schedule (PERT)', 'Estimate project duration from optimistic, likely and pessimistic task estimates.',
  [{ k: 'v', l: 'One line per task: task|optimistic|likely|pessimistic', d: 'Design|5|8|14\nBuild|10|16|28\nTest|4|6|12\nLaunch|1|2|5', t: 't' }],
  v => {
    const r = rows(v.v).map(x => { const o = N(x[1]), m = N(x[2]), p = N(x[3]); return { n: x[0] || 'Task', o, m, p, mean: (o + 4 * m + p) / 6, sd: Math.max(0, (p - o) / 6) }; }).filter(x => x.n);
    if (!r.length) return note('Add at least one task: task|optimistic|likely|pessimistic.');
    const mean = r.reduce((s, x) => s + x.mean, 0), sd = Math.sqrt(r.reduce((s, x) => s + x.sd * x.sd, 0));
    return kpi([['Expected duration', num(mean, 1) + ' days'], ['P50', num(mean, 1) + ' days'], ['P80', num(mean + 0.8416 * sd, 1) + ' days'], ['P90', num(mean + 1.2816 * sd, 1) + ' days']]) +
      tbl(['Task', 'Optimistic', 'Likely', 'Pessimistic', 'PERT mean', 'Std dev'], r.map(x => [E(x.n), num(x.o, 1), num(x.m, 1), num(x.p, 1), num(x.mean, 1), num(x.sd, 1)])) +
      note('The P80 figure is the date to commit to. The PERT mean is the number to plan with, not the likely estimate.');
  });

L.add(C, 'decmatrix', 'Weighted decision matrix', 'Score options against weighted criteria and show the winner and the gaps.',
  [{ k: 'crit', l: 'Criteria: name|weight', d: 'Cost|30\nSpeed|25\nQuality|45', t: 't', r: 3 }, { k: 'opts', l: 'Options: name|score for each criterion (0-10)', d: 'Build|6|5|9\nBuy|9|8|6\nPartner|7|7|7', t: 't', r: 4 }],
  v => {
    const crit = rows(v.crit).map(x => ({ n: x[0] || 'Criterion', w: N(x[1]) })).filter(x => x.n);
    const opts = rows(v.opts).map(x => ({ n: x[0] || 'Option', s: x.slice(1).map(N) })).filter(x => x.n);
    if (!crit.length || !opts.length) return note('Add at least one criterion and one option.');
    const tw = crit.reduce((s, x) => s + x.w, 0) || 1;
    opts.forEach(o => { o.score = crit.reduce((s, c, i) => s + (o.s[i] || 0) * c.w, 0) / tw; });
    opts.sort((a, b) => b.score - a.score);
    return kpi([['Options', opts.length], ['Winner', E(opts[0].n)], ['Score', num(opts[0].score, 2)], ['Lead', num(opts[0].score - (opts[1] ? opts[1].score : 0), 2)]]) +
      tbl(['Option', ...crit.map(c => E(c.n) + ' (' + num(c.w) + '%)'), 'Weighted score', ''], opts.map(o => [E(o.n), ...o.s.slice(0, crit.length).map(num), '<b>' + num(o.score, 2) + '</b>', bar(o.score * 10)])) +
      note('Weights total ' + num(tw) + '%. If the leader is within 0.5 points of the runner-up, the decision is effectively a tie and should turn on risk or reversibility.');
  });

L.add(C, 'powerint', 'Stakeholder power and interest', 'Place stakeholders in four quadrants and get the engagement approach for each.',
  [{ k: 'v', l: 'One line per stakeholder: name|power 1-10|interest 1-10', d: 'CEO|9|9\nCFO|8|6\nHead of Sales|6|9\nWorks council|7|4\nSupplier|4|3', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Stakeholder', p: clamp(N(x[1]), 1, 10), i: clamp(N(x[2]), 1, 10) })).filter(x => x.n);
    if (!r.length) return note('Add at least one stakeholder: name|power|interest.');
    const quad = x => x.p >= 5 && x.i >= 5 ? ['Manage closely', '#c9473d'] : x.p >= 5 ? ['Keep satisfied', '#d9922b'] : x.i >= 5 ? ['Keep informed', '#2e6bd9'] : ['Monitor', '#6b7280'];
    const W = 320, H = 260, pad = 34, X = p => pad + (W - 2 * pad) * (p - 1) / 9, Y = i => H - pad - (H - 2 * pad) * (i - 1) / 9;
    return kpi([['Stakeholders', r.length], ['Manage closely', r.filter(x => x.p >= 5 && x.i >= 5).length], ['Keep satisfied', r.filter(x => x.p >= 5 && x.i < 5).length], ['Keep informed', r.filter(x => x.p < 5 && x.i >= 5).length]]) +
      svg(W, H, '<rect x="' + X(5) + '" y="12" width="' + (W - pad - X(5)) + '" height="' + (Y(5) - 12) + '" fill="rgba(201,71,61,.08)"/>' + ax(X(5), 12, X(5), H - pad) + ax(pad, Y(5), W - pad, Y(5)) + tx(W / 2, H - 6, 'interest') + tx(8, 16, 'power', 'start') + r.map(x => '<circle cx="' + X(x.p) + '" cy="' + Y(x.i) + '" r="4.5" fill="' + quad(x)[1] + '"/><text x="' + (X(x.p) + 7) + '" y="' + (Y(x.i) + 3) + '" font-size="8.5" fill="var(--ink)">' + E(x.n.slice(0, 16)) + '</text>').join('')) +
      tbl(['Stakeholder', 'Power', 'Interest', 'Approach'], r.map(x => [E(x.n), x.p, x.i, '<b style="color:' + quad(x)[1] + '">' + quad(x)[0] + '</b>'])) +
      note('High power and high interest need a named relationship owner and a regular cadence. Low power and low interest only need monitoring.');
  });

L.add(C, 'compcal', 'Compliance calendar', 'Upcoming obligations with days remaining and the next recurrence.',
  [{ k: 'v', l: 'One line per obligation: obligation|due YYYY-MM-DD|frequency (once/monthly/quarterly/yearly)|owner', d: 'VAT return|2026-11-07|monthly|Finance\nBoard pack|2026-12-15|quarterly|CEO\nAudit filing|2027-03-31|yearly|Finance', t: 't' }],
  v => {
    const r = rows(v.v).map(x => { const d = x[1] || '', dd = L.days(d); return { n: x[0] || 'Obligation', d, f: (x[2] || 'once').toLowerCase(), own: x[3] || '', dd }; }).filter(x => x.n);
    if (!r.length) return note('Add at least one obligation: obligation|due date|frequency|owner.');
    r.sort((a, b) => (a.dd == null ? 9e9 : a.dd) - (b.dd == null ? 9e9 : b.dd));
    const late = r.filter(x => x.dd != null && x.dd < 0).length, soon = r.filter(x => x.dd != null && x.dd >= 0 && x.dd <= 30).length;
    return kpi([['Obligations', r.length], ['Overdue', late], ['Due within 30 days', soon], ['Next due', r[0] ? (r[0].d || '-') : '-']]) +
      tbl(['Obligation', 'Due', 'Days', 'Frequency', 'Owner', 'Status'], r.map(x => [E(x.n), E(x.d), x.dd == null ? '-' : num(x.dd), E(x.f), E(x.own), x.dd == null ? '' : x.dd < 0 ? '<b style="color:#c9473d">Overdue</b>' : x.dd <= 30 ? '<b style="color:#d9922b">Due soon</b>' : '<span style="color:#2e9d62">On track</span>'])) +
      note('Dates are compared with today. Recurring obligations are listed once; the status reflects the current due date.');
  }, {
  pre: () => { const a = window.__app; if (!a) return null; const out = []; a.ALLC.forEach(c => { const d = a.getC(c.id); if (d.due) out.push((c.short || c.title) + '|' + d.due + '|once|' + (d.owner || '')); }); return out.length ? { v: out.slice(0, 25).join('\n') } : null; }
});

L.add(C, 'vendorrisk', 'Vendor risk score', 'Weighted vendor criticality across data, finance, security and contract exposure.',
  [{ k: 'v', l: 'One line per vendor: vendor|criticality 1-5|data access 1-5|financial 1-5|security 1-5|contract 1-5', d: 'Cloud host|5|4|2|5|4\nAgency|2|2|3|2|2\nPayroll|4|5|4|4|3', t: 't' }],
  v => {
    const r = rows(v.v).map(x => { const s = x.slice(1, 6).map(n => clamp(N(n), 1, 5)); return { n: x[0] || 'Vendor', s, sc: s[0] * 0.3 + s[1] * 0.25 + s[2] * 0.15 + s[3] * 0.2 + s[4] * 0.1 }; }).filter(x => x.n);
    if (!r.length) return note('Add at least one vendor with five 1-5 scores.');
    r.sort((a, b) => b.sc - a.sc);
    const tier = s => s >= 4 ? ['Tier 1', '#c9473d', 'Board visibility, annual audit, exit plan'] : s >= 3 ? ['Tier 2', '#d9922b', 'Annual review, security questionnaire'] : ['Tier 3', '#2e9d62', 'Light-touch review'];
    return kpi([['Vendors', r.length], ['Tier 1', r.filter(x => x.sc >= 4).length], ['Highest score', num(r[0].sc, 2)], ['Average', num(r.reduce((s, x) => s + x.sc, 0) / r.length, 2)]]) +
      tbl(['Vendor', 'Criticality', 'Data', 'Financial', 'Security', 'Contract', 'Score', 'Tier'], r.map(x => { const t = tier(x.sc); return [E(x.n), ...x.s, num(x.sc, 2), '<b style="color:' + t[1] + '">' + t[0] + '</b>']; })) +
      note('Weights: criticality 30%, data 25%, security 20%, financial 15%, contract 10%. Tier 1 vendors need an exit plan and an annual review.');
  }, {
  push: v => { const list = rows(v.v).map(x => { const s = x.slice(1, 6).map(n => clamp(N(n), 1, 5)); const sc = s[0] * 0.3 + s[1] * 0.25 + s[2] * 0.15 + s[3] * 0.2 + s[4] * 0.1; return (x[0] || '') + ' (vendor score ' + sc.toFixed(2) + ', tier ' + (sc >= 4 ? 1 : sc >= 3 ? 2 : 3) + ')'; }).filter(x => x.length > 4); return L.pushRisks(list); }
});

L.add(C, 'scen', 'Scenario planning', 'Revenue, gross profit and the change against base for best, base and worst cases.',
  [{ k: 'rev', l: 'Base revenue', d: '10000000' }, { k: 'm', l: 'Base gross margin %', d: '35' }, { k: 'br', l: 'Best case revenue change %', d: '12' }, { k: 'bm', l: 'Best case margin change (points)', d: '2' }, { k: 'wr', l: 'Worst case revenue change %', d: '-18' }, { k: 'wm', l: 'Worst case margin change (points)', d: '-6' }],
  v => {
    const rev = N(v.rev), m = N(v.m), rowsO = [
      ['Best', rev * (1 + N(v.br) / 100), m + N(v.bm)],
      ['Base', rev, m],
      ['Worst', rev * (1 + N(v.wr) / 100), m + N(v.wm)]
    ].map(x => ({ n: x[0], r: x[1], m: x[2], gp: x[1] * x[2] / 100 }));
    const base = rowsO[1];
    return kpi([['Best gross profit', num(rowsO[0].gp)], ['Base gross profit', num(base.gp)], ['Worst gross profit', num(rowsO[2].gp)], ['Worst downside', num(rowsO[2].gp - base.gp)]]) +
      tbl(['Scenario', 'Revenue', 'Margin', 'Gross profit', 'vs base'], rowsO.map(x => [E(x.n), num(x.r), pct(x.m), num(x.gp), '<span style="color:' + (x.gp >= base.gp ? '#2e9d62' : '#c9473d') + '">' + num(x.gp - base.gp) + '</span>'])) +
      note('The worst case is the number to fund against. If the worst case breaks a covenant or the cash buffer, reduce fixed costs now.');
  });

L.add(C, 'premortem', 'Pre-mortem prioritisation', 'Rank failure modes by risk priority number and surface the ones to fix first.',
  [{ k: 'v', l: 'One line per failure mode: failure|likelihood 1-5|impact 1-5|detectability 1-5 (5 = hard to detect)', d: 'Demand below plan|4|5|3\nKey hire leaves|3|4|4\nSupplier misses launch|3|5|2\nRegulator blocks|2|5|5', t: 't' }],
  v => {
    const r = rows(v.v).map(x => { const l = clamp(N(x[1]), 1, 5), i = clamp(N(x[2]), 1, 5), d = clamp(N(x[3]), 1, 5); return { n: x[0] || 'Failure', l, i, d, rpn: l * i * d }; }).filter(x => x.n);
    if (!r.length) return note('Add at least one failure mode: failure|likelihood|impact|detectability.');
    r.sort((a, b) => b.rpn - a.rpn);
    return kpi([['Failure modes', r.length], ['Top RPN', r[0].rpn], ['Above 60', r.filter(x => x.rpn >= 60).length], ['Top risk', E(r[0].n)]]) +
      tbl(['Failure mode', 'L', 'I', 'D', 'RPN', 'Priority'], r.map(x => [E(x.n), x.l, x.i, x.d, '<b>' + x.rpn + '</b>', x.rpn >= 60 ? '<b style="color:#c9473d">Act now</b>' : x.rpn >= 30 ? '<b style="color:#d9922b">Plan a control</b>' : '<span style="color:#2e9d62">Monitor</span>'])) +
      note('RPN = likelihood x impact x detectability. A high score with high detectability is still dangerous because you will not see it coming.');
  }, {
  push: v => { const list = rows(v.v).map(x => (x[0] || '') + ' (pre-mortem RPN ' + (clamp(N(x[1]), 1, 5) * clamp(N(x[2]), 1, 5) * clamp(N(x[3]), 1, 5)) + ')').filter(x => x.length > 4); return L.pushRisks(list); }
});
})();
