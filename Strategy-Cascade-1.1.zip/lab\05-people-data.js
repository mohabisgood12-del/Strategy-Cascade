/* Strategy Cascade Lab - people, data and technology tools */
(() => {
'use strict';
const L = window.__lab; if (!L) return;
const { E, N, num, pct, rows, tbl, kpi, bar, note, svg, ax, tx, clamp, col } = L;

/* ---------------- people and organisation ---------------- */
const P = 'People and organisation';

L.add(P, 'headcount', 'Headcount plan and cost', 'Fully loaded cost by role, monthly and annual totals, and the share of each role.',
  [{ k: 'v', l: 'One line per role: role|headcount|annual salary|benefits %', d: 'Engineering|12|95000|22\nSales|8|70000|18\nOperations|6|55000|20', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Role', h: N(x[1]), s: N(x[2]), b: N(x[3]) })).filter(x => x.n);
    if (!r.length) return note('Add at least one role: role|headcount|salary|benefits %.');
    r.forEach(x => x.cost = x.h * x.s * (1 + x.b / 100));
    const total = r.reduce((s, x) => s + x.cost, 0), heads = r.reduce((s, x) => s + x.h, 0);
    return kpi([['Headcount', num(heads)], ['Annual cost', num(total)], ['Monthly cost', num(total / 12)], ['Average cost per head', num(total / (heads || 1))]]) +
      tbl(['Role', 'Heads', 'Salary', 'Benefits', 'Loaded cost', 'Share'], r.map(x => [E(x.n), num(x.h), num(x.s), pct(x.b), num(x.cost), pct(x.cost / total * 100)])) +
      note('Fully loaded cost includes benefits, payroll taxes and employer contributions. Use it for budget, not base salary.');
  });

L.add(P, 'attrition', 'Attrition cost', 'The annual cost of leavers including replacement, hiring and lost productivity.',
  [{ k: 'hc', l: 'Headcount', d: '200' }, { k: 'att', l: 'Annual attrition %', d: '14' }, { k: 'sal', l: 'Average salary', d: '65000' }, { k: 'repl', l: 'Replacement cost % of salary', d: '20' }, { k: 'ramp', l: 'Ramp months at reduced output', d: '3' }, { k: 'prod', l: 'Productivity loss during ramp %', d: '50' }],
  v => {
    const hc = N(v.hc), att = N(v.att) / 100, sal = N(v.sal), repl = N(v.repl) / 100, ramp = N(v.ramp), prod = N(v.prod) / 100;
    const leavers = hc * att, repCost = leavers * sal * repl, prodCost = leavers * sal / 12 * ramp * prod, total = repCost + prodCost;
    return kpi([['Leavers per year', num(leavers, 1)], ['Replacement cost', num(repCost)], ['Productivity loss', num(prodCost)], ['Total cost', num(total)], ['Cost per leaver', num(leavers ? total / leavers : 0)]]) +
      tbl(['Component', 'Annual cost'], [['Recruitment and onboarding', num(repCost)], ['Lost output during ramp', num(prodCost)], ['<b>Total</b>', '<b>' + num(total) + '</b>'], ['Share of payroll', pct(hc * sal ? total / (hc * sal) * 100 : 0)]]) +
      note('A 1 point fall in attrition at this headcount saves ' + num(hc * 0.01 * (sal * repl + sal / 12 * ramp * prod)) + ' a year.');
  });

L.add(P, 'skills', 'Skills gap matrix', 'Weighted gap between required and current capability, ranked by priority.',
  [{ k: 'v', l: 'One line per skill: skill|required 1-5|current 1-5|people affected', d: 'Data analysis|4|2|18\nNegotiation|4|3|9\nAI literacy|3|1|40\nProject management|4|4|12', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Skill', req: clamp(N(x[1]), 1, 5), cur: clamp(N(x[2]), 1, 5), p: N(x[3]) })).filter(x => x.n);
    if (!r.length) return note('Add at least one skill: skill|required|current|people affected.');
    r.forEach(x => { x.gap = Math.max(0, x.req - x.cur); x.w = x.gap * (x.p || 1); });
    r.sort((a, b) => b.w - a.w);
    const max = r[0].w || 1, totalGap = r.reduce((s, x) => s + x.gap, 0);
    return kpi([['Skills', r.length], ['Total gap points', num(totalGap)], ['Largest gap', E(r[0].n)], ['At or above target', r.filter(x => x.gap === 0).length]]) +
      tbl(['Skill', 'Required', 'Current', 'Gap', 'People', 'Priority', ''], r.map(x => [E(x.n), x.req, x.cur, x.gap ? '<b style="color:#c9473d">' + x.gap + '</b>' : '0', num(x.p), num(x.w), bar(x.w / max * 100, '#7a5cd6')])) +
      note('Priority is gap x people affected. Fix the top two first; a broad programme across every skill rarely lands.');
  });

L.add(P, 'compband', 'Compensation band checker', 'Compa-ratio and position in band for each role, with flags outside the range.',
  [{ k: 'v', l: 'One line per role: role|band min|band mid|band max|actual salary', d: 'Analyst|45000|55000|65000|52000\nManager|70000|85000|100000|104000\nDirector|110000|135000|160000|128000', t: 't' }],
  v => {
    const r = rows(v.v).map(x => { const min = N(x[1]), mid = N(x[2]), max = N(x[3]), a = N(x[4]); return { n: x[0] || 'Role', min, mid, max, a, cr: mid ? a / mid * 100 : NaN }; }).filter(x => x.n);
    if (!r.length) return note('Add at least one role: role|min|mid|max|actual.');
    const flag = x => x.a < x.min ? ['Below band', '#c9473d'] : x.a > x.max ? ['Above band', '#d9922b'] : ['In band', '#2e9d62'];
    return kpi([['Roles', r.length], ['Below band', r.filter(x => x.a < x.min).length], ['Above band', r.filter(x => x.a > x.max).length], ['Average compa-ratio', pct(r.reduce((s, x) => s + (x.cr || 0), 0) / r.length)]]) +
      tbl(['Role', 'Min', 'Mid', 'Max', 'Actual', 'Compa-ratio', 'Position', 'Status'], r.map(x => { const f = flag(x); return [E(x.n), num(x.min), num(x.mid), num(x.max), num(x.a), pct(x.cr), pct((x.a - x.min) / ((x.max - x.min) || 1) * 100), '<b style="color:' + f[1] + '">' + f[0] + '</b>']; })) +
      note('Compa-ratio is salary divided by band midpoint. A healthy range is 80-120%. Anyone above the maximum needs a documented exception.');
  });

L.add(P, 'engage', 'Engagement driver scoring', 'Weighted engagement score and the drivers dragging it down.',
  [{ k: 'v', l: 'One line per driver: driver|score 0-10|weight %', d: 'Purpose|8|20\nManager|6|25\nGrowth|4|20\nRecognition|5|15\nWorkload|3|20', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Driver', s: clamp(N(x[1]), 0, 10), w: Math.max(0, N(x[2])) })).filter(x => x.n);
    if (!r.length) return note('Add at least one driver: driver|score|weight.');
    const tw = r.reduce((s, x) => s + x.w, 0) || 1, score = r.reduce((s, x) => s + x.s * x.w, 0) / tw;
    const sorted = r.slice().sort((a, b) => a.s - b.s);
    return kpi([['Weighted score', num(score, 2) + ' / 10'], ['Strongest', E(r.slice().sort((a, b) => b.s - a.s)[0].n)], ['Weakest', E(sorted[0].n)], ['Weights', num(tw) + '%']]) +
      tbl(['Driver', 'Score', 'Weight', 'Contribution', ''], r.map(x => [E(x.n), num(x.s, 1), pct(x.w), num(x.s * x.w / tw, 2), bar(x.s * 10, x.s < 5 ? '#c9473d' : '#2e9d62')])) +
      note('Fix the lowest-scoring high-weight driver first. Raising the weakest driver by 2 points would lift the total by ' + num(2 * sorted[0].w / tw, 2) + '.');
  });

L.add(P, 'hirefunnel', 'Hiring funnel', 'Stage-by-stage hiring conversion, time to hire and cost per hire.',
  [{ k: 'app', l: 'Applicants', d: '400' }, { k: 'scr', l: 'Application to screen %', d: '40' }, { k: 'int', l: 'Screen to interview %', d: '50' }, { k: 'off', l: 'Interview to offer %', d: '25' }, { k: 'acc', l: 'Offer acceptance %', d: '80' }, { k: 'days', l: 'Days per stage', d: '6' }, { k: 'cost', l: 'Total recruiting cost', d: '24000' }],
  v => {
    const a = N(v.app), s = a * N(v.scr) / 100, i = s * N(v.int) / 100, o = i * N(v.off) / 100, h = o * N(v.acc) / 100;
    const stages = 5, tth = stages * N(v.days);
    return kpi([['Hires', num(h, 1)], ['Overall conversion', a ? pct(h / a * 100, 2) : 'n/a'], ['Time to hire', num(tth) + ' days'], ['Cost per hire', h ? num(N(v.cost) / h) : 'n/a']]) +
      tbl(['Stage', 'Count', 'Conversion', 'Lost'], [['Applicants', num(a), '', ''], ['Screened', num(s), pct(N(v.scr)), num(a - s)], ['Interviewed', num(i), pct(N(v.int)), num(s - i)], ['Offers', num(o), pct(N(v.off)), num(i - o)], ['Hires', num(h, 1), pct(N(v.acc)), num(o - h)]]) +
      note('The weakest stage is where to invest. If acceptance is low, the problem is usually the offer or the process, not sourcing.');
  });

/* ---------------- data and technology ---------------- */
const T = 'Data and technology';

L.add(T, 'dq', 'Data quality scorecard', 'Weighted quality score across dimensions, with the weakest area and a grade.',
  [{ k: 'v', l: 'One line per dimension: dimension|score 0-100|weight %', d: 'Completeness|92|25\nAccuracy|78|30\nTimeliness|85|20\nConsistency|70|15\nValidity|88|10', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Dimension', s: clamp(N(x[1]), 0, 100), w: Math.max(0, N(x[2])) })).filter(x => x.n);
    if (!r.length) return note('Add at least one dimension: dimension|score|weight.');
    const tw = r.reduce((s, x) => s + x.w, 0) || 1, sc = r.reduce((s, x) => s + x.s * x.w, 0) / tw;
    const worst = r.slice().sort((a, b) => a.s - b.s)[0];
    const grade = sc >= 90 ? ['A', '#2e9d62'] : sc >= 80 ? ['B', '#2e6bd9'] : sc >= 70 ? ['C', '#d9922b'] : ['D', '#c9473d'];
    return kpi([['Weighted score', num(sc, 1)], ['Grade', '<b style="color:' + grade[1] + '">' + grade[0] + '</b>'], ['Weakest', E(worst.n)], ['Dimensions', r.length]]) +
      tbl(['Dimension', 'Score', 'Weight', 'Contribution', ''], r.map(x => [E(x.n), num(x.s), pct(x.w), num(x.s * x.w / tw, 1), bar(x.s, x.s < 70 ? '#c9473d' : x.s < 85 ? '#d9922b' : '#2e9d62')])) +
      note('Do not report a single quality score without the dimensions behind it. The weakest dimension is the one that breaks decisions.');
  });

L.add(T, 'cloud', 'Cloud cost estimator', 'Monthly and annual run rate by resource, with the largest cost lines.',
  [{ k: 'v', l: 'One line per resource: resource|quantity|unit cost per month|months', d: 'Compute|40|120|12\nStorage|50|8|12\nDatabase|4|600|12\nCDN|1|300|12', t: 't' }],
  v => {
    const r = rows(v.v).map(x => ({ n: x[0] || 'Resource', q: N(x[1]), c: N(x[2]), m: Math.max(1, N(x[3])) })).filter(x => x.n);
    if (!r.length) return note('Add at least one resource: resource|quantity|unit cost|months.');
    r.forEach(x => x.total = x.q * x.c * x.m);
    const total = r.reduce((s, x) => s + x.total, 0), monthly = r.reduce((s, x) => s + x.q * x.c, 0);
    return kpi([['Monthly run rate', num(monthly)], ['Annual run rate', num(monthly * 12)], ['Horizon cost', num(total)], ['Largest line', E(r.slice().sort((a, b) => b.total - a.total)[0].n)]]) +
      tbl(['Resource', 'Quantity', 'Unit cost', 'Monthly', 'Horizon cost', 'Share'], r.map(x => [E(x.n), num(x.q), num(x.c, 2), num(x.q * x.c), num(x.total), pct(total ? x.total / total * 100 : 0)])) +
      note('A 15% commitment discount on the top two lines would save ' + num(r.slice().sort((a, b) => b.total - a.total).slice(0, 2).reduce((s, x) => s + x.total, 0) * 0.15) + ' over the horizon.');
  });

L.add(T, 'techdebt', 'Technical debt prioritisation', 'Rank debt items by impact and risk against the effort to fix them.',
  [{ k: 'v', l: 'One line per item: item|business impact 1-5|effort 1-5|risk 1-5', d: 'Legacy auth|5|3|5\nNo test coverage|4|4|4\nManual deploy|3|2|3\nOld reporting stack|4|5|2', t: 't' }],
  v => {
    const r = rows(v.v).map(x => { const i = clamp(N(x[1]), 1, 5), e = clamp(N(x[2]), 1, 5), k = clamp(N(x[3]), 1, 5); return { n: x[0] || 'Item', i, e, k, sc: i * k / e }; }).filter(x => x.n);
    if (!r.length) return note('Add at least one item: item|impact|effort|risk.');
    r.sort((a, b) => b.sc - a.sc);
    const max = r[0].sc || 1;
    return kpi([['Items', r.length], ['Top priority', E(r[0].n)], ['Score', num(r[0].sc, 1)], ['Quick wins', r.filter(x => x.e <= 2 && x.i >= 4).length]]) +
      tbl(['Item', 'Impact', 'Effort', 'Risk', 'Score', 'Sequence', ''], r.map((x, i) => [E(x.n), x.i, x.e, x.k, num(x.sc, 1), i + 1, bar(x.sc / max * 100, '#7a5cd6')])) +
      note('Score = impact x risk / effort. Quick wins are high impact with low effort; do those before the large re-platforming work.');
  });

L.add(T, 'cyberale', 'Cyber risk and annual loss expectancy', 'Single and annual loss expectancy per asset, and whether a control pays for itself.',
  [{ k: 'v', l: 'One line per asset: asset|value|exposure factor %|annual rate of occurrence', d: 'Customer database|4000000|60|0.3\nFinance system|1500000|40|0.2\nWebsite|500000|25|1.5', t: 't' }, { k: 'ctrl', l: 'Annual cost of the proposed control', d: '250000' }, { k: 'red', l: 'Risk reduction from the control %', d: '50' }],
  v => {
    const r = rows(v.v).map(x => { const val = N(x[1]), ef = N(x[2]) / 100, aro = N(x[3]); return { n: x[0] || 'Asset', val, ef, aro, sle: val * ef, ale: val * ef * aro }; }).filter(x => x.n);
    if (!r.length) return note('Add at least one asset: asset|value|exposure factor|annual rate.');
    const total = r.reduce((s, x) => s + x.ale, 0), save = total * N(v.red) / 100, ctrl = N(v.ctrl), net = save - ctrl;
    return kpi([['Total ALE', num(total)], ['Control benefit', num(save)], ['Control cost', num(ctrl)], ['Net benefit', num(net)], ['ROI', ctrl ? pct(net / ctrl * 100) : 'n/a']]) +
      tbl(['Asset', 'Value', 'Exposure', 'ARO', 'SLE', 'ALE'], r.map(x => [E(x.n), num(x.val), pct(x.ef * 100), num(x.aro, 2), num(x.sle), num(x.ale)])) +
      note(net > 0 ? 'The control is worth buying on these assumptions. Test the exposure factor and annual rate with your security team.' : 'The control does not pay for itself on these assumptions. Reduce scope or find a cheaper option.');
  });

L.add(T, 'aiusecase', 'AI use-case scoring', 'Score use cases on value, feasibility, data readiness and risk, then sequence them.',
  [{ k: 'v', l: 'One line per use case: use case|value 1-5|feasibility 1-5|data readiness 1-5|risk 1-5', d: 'Support triage|5|4|4|2\nDemand forecast|4|3|2|2\nContract review|4|3|3|4', t: 't' }],
  v => {
    const r = rows(v.v).map(x => { const a = clamp(N(x[1]), 1, 5), b = clamp(N(x[2]), 1, 5), c = clamp(N(x[3]), 1, 5), d = clamp(N(x[4]), 1, 5); return { n: x[0] || 'Use case', a, b, c, d, sc: (a * 0.4 + b * 0.25 + c * 0.2) * (1 - (d - 1) * 0.12) }; }).filter(x => x.n);
    if (!r.length) return note('Add at least one use case with four 1-5 scores.');
    r.sort((a, b) => b.sc - a.sc);
    const max = r[0].sc || 1;
    const tier = x => x.sc >= 3.6 ? ['Do now', '#2e9d62'] : x.sc >= 2.6 ? ['Pilot', '#2e6bd9'] : x.sc >= 1.8 ? ['Prepare', '#d9922b'] : ['Defer', '#c9473d'];
    return kpi([['Use cases', r.length], ['Do now', r.filter(x => x.sc >= 3.6).length], ['Top score', num(r[0].sc, 2)], ['Top case', E(r[0].n)]]) +
      tbl(['Use case', 'Value', 'Feasibility', 'Data', 'Risk', 'Score', 'Tier', ''], r.map(x => { const t = tier(x); return [E(x.n), x.a, x.b, x.c, x.d, num(x.sc, 2), '<b style="color:' + t[1] + '">' + t[0] + '</b>', bar(x.sc / max * 100)]; })) +
      note('Score = (value x 40% + feasibility x 25% + data x 20%) reduced by risk. A high-value case with weak data is a data project first.');
  });

L.add(T, 'downtime', 'Cost of downtime', 'Lost revenue, recovery cost and the annualised exposure for an outage.',
  [{ k: 'rev', l: 'Revenue per hour', d: '250000' }, { k: 'aff', l: 'Share of revenue affected %', d: '60' }, { k: 'hours', l: 'Outage length (hours)', d: '4' }, { k: 'rec', l: 'Recovery and overtime cost', d: '30000' }, { k: 'freq', l: 'Expected outages per year', d: '3' }],
  v => {
    const rev = N(v.rev), aff = N(v.aff) / 100, h = N(v.hours), rec = N(v.rec), f = N(v.freq);
    const lost = rev * aff * h, per = lost + rec;
    return kpi([['Lost revenue', num(lost)], ['Recovery cost', num(rec)], ['Cost per outage', num(per)], ['Annual exposure', num(per * f)], ['Cost per minute', num(per / (h * 60))]]) +
      tbl(['Item', 'Value'], [['Revenue at risk per hour', num(rev * aff)], ['Outage hours', num(h)], ['Per outage', num(per)], ['Outages per year', num(f)], ['Annualised', num(per * f)]]) +
      note('Compare the annual exposure with the cost of resilience work. If the exposure is more than three times the fix, fund the fix.');
  });
})();
