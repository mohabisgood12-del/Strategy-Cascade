$ErrorActionPreference = 'Stop'
$dir = 'C:\Users\LENOVO\Documents\Default Project\Strategy-Cascade-main'
$p = Join-Path $dir 'index.html'
$t = [System.IO.File]::ReadAllText($p, [System.Text.Encoding]::UTF8)
# remove a previously injected lab bundle
$mark = '<script>/* Strategy Cascade Lab'
$start = $t.IndexOf($mark)
if ($start -ge 0) {
  $end = $t.IndexOf('</script>', $start)
  if ($end -lt 0) { throw 'Could not find the end of the old lab block' }
  $t = $t.Substring(0, $start) + $t.Substring($end + 9)
  Write-Output 'removed old lab bundle'
}
$files = Get-ChildItem -LiteralPath (Join-Path $dir 'lab') -Filter '*.js' | Where-Object { $_.Name -notlike '_*' } | Sort-Object Name
$parts = @()
foreach ($f in $files) { $parts += [System.IO.File]::ReadAllText($f.FullName, [System.Text.Encoding]::UTF8) }
$js = $parts -join "`n`n"
$i = $t.LastIndexOf('</body>')
$block = "<script>/* Strategy Cascade Lab - 72 working analysis tools, command palette and app polish */`n" + $js + "`n</script>`n"
$out = $t.Substring(0, $i) + $block + $t.Substring($i)
[System.IO.File]::WriteAllText($p, $out, (New-Object System.Text.UTF8Encoding($false)))
Write-Output ("rebuilt, length {0}" -f $out.Length)
