import { spawn } from 'node:child_process';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const FILE = 'file:///C:/Users/LENOVO/Documents/Default%20Project/Strategy-Cascade-main/index.html';
const PORT = 9341;
const OUT = 'C:\\Users\\LENOVO\\AppData\\Local\\Temp\\opencode';
const profile = mkdtempSync(join(tmpdir(), 'sc-shot-'));
const chrome = spawn(CHROME, ['--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check', '--allow-file-access-from-files', '--hide-scrollbars', `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, '--window-size=1440,1000', 'about:blank'], { stdio: 'ignore' });
const sleep = ms => new Promise(r => setTimeout(r, ms));
let v;
for (let i = 0; i < 40; i++) { try { const r = await fetch(`http://127.0.0.1:${PORT}/json/version`); if (r.ok) { v = await r.json(); break; } } catch (e) {} await sleep(250); }
const ws = new WebSocket(v.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
let id = 0; const pending = new Map();
ws.onmessage = e => { const m = JSON.parse(e.data); if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); } };
const send = (method, params = {}, sessionId) => { const mid = ++id; ws.send(JSON.stringify({ id: mid, method, params, ...(sessionId ? { sessionId } : {}) })); return new Promise(res => pending.set(mid, res)); };
const t = await send('Target.createTarget', { url: 'about:blank' });
const a = await send('Target.attachToTarget', { targetId: t.result.targetId, flatten: true });
const sid = a.result.sessionId;
await send('Runtime.enable', {}, sid);
await send('Page.enable', {}, sid);
await send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 1000, deviceScaleFactor: 1, mobile: false }, sid);
await send('Page.navigate', { url: FILE }, sid);
await sleep(6000);
const ev = async (expression) => {
  const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true }, sid);
  if (r.result && r.result.exceptionDetails) return { ERROR: (r.result.exceptionDetails.exception && r.result.exceptionDetails.exception.description) || r.result.exceptionDetails.text };
  return r.result && r.result.result ? r.result.result.value : 'NO-VALUE';
};
await ev('1+1');
const unlock = () => ev(`(()=>{ const l=document.getElementById('lock'); if(l) l.remove(); document.body.classList.remove('locked'); return true; })()`);
// the app resolves its own auth state a few seconds after load, so unlock just before each shot
await unlock();
await ev(`(()=>{ const a=window.__app; a.ALLC.slice(0,5).forEach((c,i)=>{const d=a.getC(c.id); d.owner=['Ana Silva','Ben Okafor','Chen Wu','Dara Patel','Eli Berg'][i]; d.due='2026-1'+(i+1)+'-15'; d.st=[1,2,4,3,0][i]; d.rk='Supplier concentration risk'; d.kp.push({k:'Gross margin',b:'32',t:'40',h:'+8 pts'});}); a.render(); return true; })()`);
await sleep(600);
async function shot(name) {
  await unlock();
  const r = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false }, sid);
  writeFileSync(join(OUT, name), Buffer.from(r.result.data, 'base64'));
  return name;
}
const shots = [];
shots.push(await shot('sc-home.png'));
await ev(`window.__app.go('lab')`);
await sleep(500);
shots.push(await shot('sc-lab-page.png'));
await ev(`window.__app.go('home')`);
await sleep(300);
await ev(`window.__lab.open('riskreg')`);
await sleep(500);
shots.push(await shot('sc-lab-risk.png'));
await ev(`window.__lab.open('be')`);
await sleep(400);
shots.push(await shot('sc-lab-be.png'));
await ev(`document.querySelector('#labm').remove(); window.__lab.palette();`);
await sleep(400);
shots.push(await shot('sc-palette.png'));
await ev(`document.querySelector('#cp').classList.remove('on'); window.__lab.open('plan90')`);
await sleep(500);
shots.push(await shot('sc-lab-plan.png'));
console.log(JSON.stringify({ shots, labCount: await ev('window.__lab.order.length') }, null, 2));
ws.close(); chrome.kill(); process.exit(0);
